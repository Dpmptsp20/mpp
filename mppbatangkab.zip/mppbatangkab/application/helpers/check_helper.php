<?php

function check_user(){
	
	$ci=&get_instance();
	$s=$ci->session->userdata('status');
	
	$lu=$ci->session->userdata('level');
	//$lu='admin';
	//echo 'nilai level: '.$lu.' dan nilai status: '.$s;die;
	if($s!='login_user'){
		redirect('main/coba');
	}else if($s!='login_admin'){
		redirect('main/coba');

	}
}

function check_admin(){
	
	$I=& get_instance();
	$s=$I->session->userdata('status');
	$lu=$I->session->userdata('level');
	if(($lu!='admin')&&($s!='login_admin')){
		redirect('statistic_c/loginadm');
	}
	
}
function check_adminmpp(){
	
	$I=& get_instance();
	$s=$I->session->userdata('status');
	$lu=$I->session->userdata('level');
	//var_dump($lu);die;
	if(($lu!='1' or $lu!='2')and($s!='login_admin')){
		redirect('statistic_c/loginpoktan');
	}
	
}
function uncheck_admin(){
	
	$C=& get_instance();
	$s=$C->session->userdata('status');
	$lu=$C->session->userdata('level');
	if(($lu!='admin')&&($s!='login_admin')){
		//echo 'masuk '.$s.' n '.$lu;die;
		redirect('main/sessvob');
	}
	
}







?>