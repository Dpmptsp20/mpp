<?php defined('BASEPATH') OR
exit('No direct script access allowed');

//class Home extends MY_Controller{
	class Model_statistic extends CI_Model{
	
	
	public function post($data){
		//INSERT INTO statistik(ip, tanggal, hits, online) VALUES('$ip','$tanggal','1','$waktu')
		$this->db->insert('statistik',$data);
	}
	public function posthisto($data){
		//INSERT INTO statistik(ip, tanggal, hits, online) VALUES('$ip','$tanggal','1','$waktu')
		$this->db->insert('history_alert',$data);
	}
	public function gethisto(){
		//INSERT INTO statistik(ip, tanggal, hits, online) VALUES('$ip','$tanggal','1','$waktu')
		$r=$this->db->get('history_alert');
		if($r->num_rows()>0){return $r;}else{return false;}
	}
	public function uphisto(){
		$this->db->where('status','b');
		$r=$this->db->update('history_alert',array('status'=>'s'));
		return $this->db->affected_rows();
	}
	public function upmodul($x){
		$rx=$this->getmodul($x);
		
	if($rx=='Y'){
		$te=array('id_modul'=>$x);
			//return 'ok';
			$this->db->where($te);
			$se=$this->db->update('modul',array('publish'=>'N'));
			return $this->db->affected_rows();
		}elseif($rx=='N'){
			
			$te=array('id_modul'=>$x);
			$this->db->where($te);
			$se=$this->db->update('modul',array('publish'=>'Y'));
			return $this->db->affected_rows();
		}
		
	}

	public function getmodul($n){
		//return $n;
	//$r=$this->db->get_where('modul',array('id_modul'=>$x));
		$ne=array('id_modul'=>$n);
		$this->db->where($ne);
	$se=$this->db->get('modul');
	$rc=$se->num_rows();
	//$re= $this->db->affected_rows();
	// $res=$re->row();
	//if(isset($res)){
	if($rc>0){

		 $ser=$se->row();

		if(isset($ser)) { 
			return  $ser->publish;
		 }else {
		 	return 10;
		 }
		
	
	}else{return 1000;}


	}


		
              //$pengunjungonline = mysql_num_rows(mysql_query("SELECT * FROM statistik WHERE online > '$bataswaktu'"));
		function ceklog($username,$pass){
		$s="SELECT * FROM users WHERE username='$username' AND password='$pass' AND blokir='N'";
		$ht=$this->db->query($s);
		if($ht->num_rows()>0){return $ht;}else{return false;}
		}
		function cekuser($username,$nm){
		$s="SELECT * FROM users WHERE username='$username' AND nama_lengkap='$nm' AND blokir='N'";
		$ht=$this->db->query($s);
		if($ht->num_rows()>0){return $ht;}else{return false;}
		}
		function ceklogmppanggota($username,$pass){
		$s="SELECT * FROM users WHERE username='$username' AND password='$pass' AND blokir='N' AND level<>'3'";
		$ht=$this->db->query($s);
		if($ht->num_rows()>0){return $ht;}else{return false;}
		}
public function autoDelreged(){
      $q='delete from history_alert where DATEDIFF(CURDATE(),tanggal)<=7 and status="s"';//coba satu hari dulu jika besok terhapus maka akan gnti 7
      $this->db->query($q);
  }



	
}