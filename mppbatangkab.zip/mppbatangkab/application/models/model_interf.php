<?php defined('BASEPATH') OR
exit('No direct script access allowed');

	class Model_interf extends CI_Model{
	
	//Kelola profil
	public function postprofil($data){
		$r=$this->db->insert('profil',$data);
			if($r){return true;}else{return false;}
	}
	public function postdownload($data){
		return $this->db->insert('download',$data);
	}
	function view_profil(){
		$this->db->where(array('status'=>'publish'));
	return 	$this->db->get('profil');
		}
		function view_profilall(){
	
	return 	$this->db->get('profil');
		}
public function getprofil($k){
		$kp=array('id_profil'=>$k);
		return $this->db->get_where('profil',$kp);	
	}
#DELETE
	public function delprofil($d){
	
		$k="delete from profil where id_profil=".$d;
	return $this->db->query($k);
	}
	public function delsaran($d){
	
		$k="delete from saranadu where id_saranadu=".$d;
	return $this->db->query($k);
	}
	public function delrespon($d1){
	
		$k="delete from respon where id_respon=".$d1;
	return $this->db->query($k);
	}
#DETAIL_INSTANSI

	function view_dinstansi($id){
	$q='SELECT * FROM  `instansi` as i LEFT JOIN `layanan` AS l ON l.id_instansi=i.id_instansi WHERE i.id_instansi="'.$id.'"';
		 
      $query = $this->db->query($q);
      return $query;
		//$this->db->where(array('id_instansi'=>$usg));
	//return 	$this->db->get('instansi');
		}
#update profil
	public function updateprofil($vd){
		$data=array('latarblg'=>$this->input->post("profil"),
		'video'=>$vd
		);
		$this->db->where('id_profil',$this->input->post("id"));
		$this->db->update('profil',$data);
		
	}
		public function editdownload(){
		$data=array('judul'=>$this->input->post("judul"),
		'nama_file'=>$this->input->post("nama")
		);
		$this->db->where('id_download',$this->input->post("id"));
		$this->db->update('download',$data);
		
	}
 function saveskm($k){
        $hasil=$this->db->query("INSERT INTO skm (ket)VALUES('$k')");
        return $hasil;
    }
  function saveskma($k,$i){
        $hasil=$this->db->query("INSERT INTO skm (ket,ip)VALUES('$k','$i')");
        return $hasil;
    }
 	public function getskm($id){

		$this->db->where('ip',$id);
			$re= $this->db->get('skm');
			if($re){
				return $re->result_array();
			}else{return false;}
		}
	public function view_modul($id){

			$re= $this->db->query("SELECT * FROM `tb_menu_access` WHERE `nama_menu` like '%".$id."%' ");
			if($re){
				return $re->result_array();
			}else{return false;}
		}

	function posall($nt,$dt){
		$this->db->insert($nt,$dt);
		$insert_id = $this->db->insert_id();
      return $insert_id;
	}
	function posres($dta){
		$this->db->insert('respon',$dta);
		$insert_id = $this->db->insert_id();
      return $insert_id;
	}
		public function getpelayanan($id){

		$this->db->where('id_instansi',$id);
			return $this->db->get('layanan');
		}	
		public function getres($id){

		$this->db->where('id_saranadu',$id);
			$re= $this->db->get('respon');
			if($re){
				return $re->result_array();
			}else{return false;}
		}

		#view saran aduan
			function view_saranaduan(){
		$q='SELECT s.*,r.id_respon,r.tanggal tgl_respon,r.respon FROM `saranadu` as s left join `respon` as r on s.id_saranadu=r.id_saranadu ';
	return 	$this->db->query($q);
		}


		#delete

	public function view_download(){
		$q="SELECT * FROM download ORDER BY id_download DESC";
		return $this->db->query($q);
	}
		public function deldownload($d){
	return	$this->db->where($d)->delete('download');

	}
		public function updatedownload($id,$dt){
		$this->db->where('id_download',$id);
		$r=$this->db->update('download',$dt);
			if($r){return true;}else{return false;}
	}
	public function eddownload($k){
		$kp=array('id_download'=>$k);
		return $this->db->get_where('download',$kp);
		
	}
		function viewpagingdownload($hal){
		$c=$this->db->query("select * from download ORDER BY id_download DESC limit $hal,10 ");
		if($c->num_rows()>0){return $c;}else{return false;}
	}


	function resetskm(){
		$c=$this->db->empty_table('skm');
		if($c){return $c;}else{return false;}
	}
}