<?php defined('BASEPATH') OR
exit('No direct script access allowed');

//class Home extends MY_Controller{
	class Model_berita extends CI_Model{
	
	
	public function post($data){
		$r=$this->db->insert('berita',$data);
			if($r){return true;}else{return false;}
	}
	public function addharga($data){
		$r=$this->db->insert('update_harga',$data);
			if($r){return true;}else{return false;}
	}
	function view_berita(){
		$q="SELECT *
FROM berita, kategori
WHERE berita.id_kategori = kategori.id_kategori
AND berita.status = '1'";
return $this->db->query($q);
		}
		public function view_ber(){
	
return $this->db->get('berita');
		}
	function view_banner(){
			return $this->db->get('banner');
		}

		//view pagging
	function viewpaging($hal){
		$c=$this->db->query("select * from berita limit $hal,10 ");
		if($c->num_rows()>0){return $c;}else{return false;}
	}
	function view_pagging($hal){
		$c=$this->db->query("SELECT *
FROM berita, kategori
WHERE berita.id_kategori = kategori.id_kategori
AND berita.status = '1'
ORDER BY berita.id_berita DESC
LIMIT $hal , 5");
		if($c->num_rows()>0){return $c;}else{return false;}
	}
	function view_paggingsearch($cr){
		$c=$this->db->query("SELECT *
FROM berita, kategori
WHERE berita.id_kategori = kategori.id_kategori
AND berita.status = '1' AND berita.judul like '%".$cr."%' or berita.isi_berita like '%".$cr."%'
ORDER BY berita.id_berita DESC
"
);
		if($c->num_rows()>0){return $c;}else{return false;}
	}
function view_berit(){
		$c=$this->db->query("SELECT *
FROM berita, kategori
WHERE berita.id_kategori = kategori.id_kategori
AND berita.status = '1'
ORDER BY berita.id_berita DESC
"
);
		if($c->num_rows()>0){return $c;}else{return false;}
	}

	function viewpagingbanner($hal){
		$c=$this->db->query("select * from banner limit $hal,10");
		if($c->num_rows()>0){return $c;}else{return false;}
	}
	public function detailberita($id){
		
		$q='SELECT * FROM berita  
                      WHERE id_berita="'.$id.'"';
		return $this->db->query($q);
	}

	public function updatedibaca($id,$dibaca){
		$ud=$dibaca+1 ;
		$q='UPDATE berita SET dibaca='.$ud.'
              WHERE id_berita="'.$id.'"';
		 $this->db->query($q);
	}
	public function carouselberita(){
		
		$q="SELECT * FROM berita,kategori  WHERE berita.id_kategori=kategori.id_kategori and berita.status='1' and berita.headline='Y' ORDER BY berita.id_berita DESC LIMIT 5";
		return $this->db->query($q);
	}


	public function editberita($k){
		$kp=array('id_berita'=>$k);
		return $this->db->get_where('berita',$kp);
		
	}
	

	public function editContent(){
		$data=array('kategori'=>$this->input->post("kat"),
		'content'=>$this->input->post("content")
		);
		$this->db->where('id',$this->input->post("id"));
		$this->db->update('content',$data);
		
	}	
	#DELETE
	public function delberita($d){
		//$k="DELETE FROM berita WHERE id_berita='".$d."' and id_kategori<>30";
		//$k="delete from content where id=".$d;
		$k="delete from berita where id_berita=".$d;
	return $this->db->query($k);
	}


	public function updateberita($id,$dt){
		$this->db->where('id_berita',$id);
		$r=$this->db->update('berita',$dt);
			if($r){return true;}else{return false;}
	}
public function updown($idf){
		//$this->db->where('id_download',$id);
	//	$r=$this->db->update('download',$dt);
	$r=$this->db->query( "update download set hits=hits+1 where nama_file='$idf'");
			if($r){return true;}else{return false;}
	}
	
}