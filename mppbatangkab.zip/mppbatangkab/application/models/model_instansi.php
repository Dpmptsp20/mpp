<?php defined('BASEPATH') OR
exit('No direct script access allowed');

//class Home extends MY_Controller{
	class Model_instansi extends CI_Model{
	
	//Kelola Instansi
	public function postint($data){
		$r=$this->db->insert('instansi',$data);
			if($r){return true;}else{return false;}
	}
	
	function view_instansi(){
	return 	$this->db->query("SELECT * FROM `instansi` WHERE SUBSTRING(kd_dinas,1,1)!='P'");
//return $this->db->query($q);
		}
		function view_instansiall(){
	return 	$this->db->query("SELECT * FROM `instansi`");
//return $this->db->query($q);
		}
function view_instansigov(){
		//$q="SELECT * FROM instansi";
	return 	$this->db->query("SELECT * FROM `instansi` WHERE SUBSTRING(kd_dinas,1,1)='P'");
//return $this->db->query($q);
		}
public function getinstansi($k){
		$kp=array('id_instansi'=>$k);
		return $this->db->get_where('instansi',$kp);	
	}
#DELETE
	public function deleteint($d){
			$k="delete from instansi where id_instansi=".$d;
	return $this->db->query($k);
	}

	public function view_ber(){
			return $this->db->get('instansi');
		}

		function view_layananins(){
			return $this->db->query('SELECT distinct(i.nm_dinas),l.id_layanan,l.info_layanan, i.id_instansi,l.syarat,l.prosedur FROM `instansi` as i INNER JOIN `layanan` as l ON i.id_instansi=l.id_instansi ');
		}
	function view_layananinssy($i){
			return $this->db->query('SELECT distinct(i.nm_dinas),i.id_instansi,l.* FROM `instansi` as i INNER JOIN `layanan` as l ON i.id_instansi=l.id_instansi where l.id_layanan="'.$i.'"');
		}

		//view pagging
	function viewpaging($hal){
		$c=$this->db->query("select * from instansi limit $hal,10 ");
		if($c->num_rows()>0){return $c;}else{return false;}
	}

	function view_paggingsearch($cr){
		$c=$this->db->query("SELECT *
FROM instansi, kategori
WHERE instansi.id_kategori = kategori.id_kategori
AND instansi.status = '1' AND instansi.judul like '%".$cr."%' or instansi.isi_instansi like '%".$cr."%'
ORDER BY instansi.id_instansi DESC
"
);
		if($c->num_rows()>0){return $c;}else{return false;}
	}
function view_berit(){
		$c=$this->db->query("SELECT *
FROM instansi, kategori
WHERE instansi.id_kategori = kategori.id_kategori
AND instansi.status = '1'
ORDER BY instansi.id_instansi DESC
"
);
		if($c->num_rows()>0){return $c;}else{return false;}
	}

	function viewpagingbanner($hal){
		$c=$this->db->query("select * from banner limit $hal,10");
		if($c->num_rows()>0){return $c;}else{return false;}
	}
	public function detail_instansi($id){
				$q='SELECT * FROM instansi,kategori    
                      WHERE instansi.id_kategori=kategori.id_kategori and instansi.id_instansi="'.$id.'"';
		return $this->db->query($q);
	}

	public function updatedibaca($id,$dibaca){
		$ud=$dibaca+1 ;
		$q='UPDATE instansi SET dibaca='.$ud.'
              WHERE id_instansi="'.$id.'"';
		 $this->db->query($q);
	}



	public function updateinstansi($id,$dt){
		$this->db->where('id_instansi',$id);
		$r=$this->db->update('instansi',$dt);
			if($r){return true;}else{return false;}
	}
	
public function poslayanan($data){
		$r=$this->db->insert('layanan',$data);
			if($r){return true;}else{return false;}
	}


}