<!DOCTYPE html>
<html lang="en">
 
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
    <link rel="icon" href="<?=base_url();?>assets/img/core-img/log.png">
   <link rel="icon" href="<?=base_url();?>assets/css/anim.css">

  <title>Admin Mal Pelayanan Publik</title>

  <!-- Custom fonts for this template-->
  <link href="<?=base_url();?>assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/DataTables/datatables.min.css"/>
  <!-- Custom styles for this template-->
  <link href="<?=base_url();?>assets/css/adm/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="<?=base_url();?>assets/adminmpp.css" rel="stylesheet">
 <script language="javascript" type="text/javascript"
src="<?php echo base_url()?>assets/tinymcpuk/tiny_mce_src.js"></script>
<script type="text/javascript">
tinyMCE.init({
        mode : "textareas",
        theme : "advanced",
        plugins : "table,youtube,advhr,advimage,advlink,emotions,flash,searchreplace,paste,directionality,noneditable,contextmenu",
        theme_advanced_buttons1_add : "fontselect,fontsizeselect",
        theme_advanced_buttons2_add : "separator,preview,zoom,separator,forecolor,backcolor,liststyle",
        theme_advanced_buttons2_add_before: "cut,copy,paste,separator,search,replace,separator",
        theme_advanced_buttons3_add_before : "tablecontrols,separator,youtube,separator",
        theme_advanced_buttons3_add : "emotions,flash",
        theme_advanced_toolbar_location : "top",
        theme_advanced_toolbar_align : "left",
        theme_advanced_statusbar_location : "bottom",
        extended_valid_elements : "hr[class|width|size|noshade]",
        file_browser_callback : "fileBrowserCallBack",
        paste_use_dialog : false,
        theme_advanced_resizing : true,
        theme_advanced_resize_horizontal : false,
        theme_advanced_link_targets : "_something=My somthing;_something2=My somthing2;_something3=My somthing3;",
        apply_source_formatting : true
});

   
</script>
</head>


  <body>
    <nav class="navbar navbar-fixed-top navbar-inverse">
      <div class="container" >
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="<?php echo base_url()?>main">DPMPTSP-Batang</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
          <!--  <li class="active"><?php echo anchor('main','Home');?></li>-->
          <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        Profil<span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                       <li><a href="<?php echo base_url()?>main/visimisi">Visi-misi</a></li>
                        <li><a href="<?php echo base_url()?>main/sejarah">Sejarah</a></li>
                        
                    </ul>
                    <!-- /.dropdown-user -->
            </li>
       
           <?php  
                if($mr){
                  $i=0;
                    foreach ($mr as $key) {
                      echo ' <li><a href="'. base_url().'main/'.$key->nama_modul.'">'.$key->static_content.'</a></li>';
                       $i+=1;
                    }
                  
                }
           ?>
            <?php 
			$s=$this->session->userdata('status');
        $l=$this->session->userdata('level');
		
			
			 ?>
          </ul>
		   <ul class="nav navbar-nav navbar-right">
			<!--<li><button class="btn btn-default"><?php echo anchor('#',' Log-In',array('class'=>'glyphicon glyphicon-log-in'));?></button></li>-->
	
			<li class="dropdown">
              <!--      <button class="btn btn-default dropdown-toggle marnav" data-toggle="dropdown" href="#">
                        <i class="glyphicon glyphicon-user"><?php if($s=='login_admin'){echo "Admin";}elseif($s=='login_user'){echo "User";}?></i> <i class="caret"></i>
                    </button> -->
                  <?php if($s!=''){
					  echo	'<ul class="dropdown-menu dropdown-user">
                      <!--  <li><a href="#"><i class="glyphicon glyphicon-user"></i> User Profile</a> </li>-->
                        <li><a href="'.base_url().'admin_loginc/editUser"><i class="glyphicon glyphicon-wrench"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="'. base_url().'main/logout"><i class="glyphicon glyphicon-log-out"></i> Logout</a>
                        </li>
                    </ul>';
				  }  ?>
                    <!-- /.dropdown-user -->
             </li>
          </ul>
     <form class="navbar-form navbar-right" style="margin-left: 40px" action="<?=base_url()?>main/cari_menu" method="post">
      <div class="input-group">
        <input type="text" name="cari_menu" class="form-control" id="carim" placeholder="Search" autocomplete="off" required>
        <div class="input-group-btn">
          <button type="submit"  id="carimenu" class="btn btn-default">
            <i class="glyphicon glyphicon-search"> Search</i>
          </button>
        </div>
      </div>
    </form>
        </div><!-- /.nav-collapse -->
	
		
         
      </div> <!-- /.container -->
    </nav> <!-- /.navbar -->

    <div class="container" id="container">

      <div class="row">
		
		
		
        <div class="col-xs-12 col-sm-12 col-lg-12 " stayle="align:center">
		
           <!--   <p class="pull-right visible-xs">
                <button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas">Nav Jadwal</button>
              </p>
    		 -->
             <!-- <div class="jumbotron">-->
        		   <div class="jum">
        			 <div class="bgtx">
        				 <div class="tx">
        				 <h2 class='h2judulweb tam'>
               Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu
Kabupaten Batang<span class="hid"> kabupaten Batang</span></h2>

                
        					<!--<p> 
        					
        					</p>-->

        				</div>
        			</div>	
             </div>
        		 
             <hr>
    		       <!-- content -->
         </div><!--/.col-xs-12.col-sm-9-->

        
        </div>
          <!--/.sidebar-offcanvas-->

      <!--<hr>-->
		    <div class="row">
              <div class ="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <!-- <div id="content" class="col-xs-12 col-sm-12 col-md-8 col-lg-8">-->
                    <div id="content" class="col-xs-12 col-sm-8 col-md-8 col-lg-8">

                       <!-- <div class="media portal" >-->
                       <?php $this->load->view($view);?>
                    </div><!--end idcontent-->
                       <div id="sidebar" class="col-xs-12 col-sm-4 col-md-4 col-lg-3">

                   
                          <h2 class="statistik"><center><u>Statistik User</u></center></h2>

                          <ul id="listsidebar">
                            <?php
                          //  var_dump( $statistik);
                              $ip      = $_SERVER['REMOTE_ADDR']; // Mendapatkan IP komputer user
                              $tanggal = date("Ymd"); // Mendapatkan tanggal sekarang
                              $waktu   = time(); // 

                              // Mencek berdasarkan IPnya, apakah user sudah pernah mengakses hari ini 
                              $s = mysql_query("SELECT * FROM statistik WHERE ip='".$ip."' AND tanggal='".$tanggal."'");
                              // Kalau belum ada, simpan data user tersebut ke database
                              if(mysql_num_rows($s) == 0){
                                mysql_query("INSERT INTO statistik(ip, tanggal, hits, online) VALUES('$ip','$tanggal','1','$waktu')");
                              } 
                              else{
                                mysql_query("UPDATE statistik SET hits=hits+1, online='$waktu' WHERE ip='$ip' AND tanggal='$tanggal'");
                              }

                              $pengunjung       = mysql_num_rows(mysql_query("SELECT * FROM statistik WHERE tanggal='$tanggal' GROUP BY ip"));
                              $sdpon=array('jmlon'=>$pengunjung);
                              $this->session->set_userdata($sdpon);
                              $totalpengunjung  = mysql_result(mysql_query("SELECT COUNT(hits) FROM statistik"), 0); 
                              $hits             = mysql_fetch_assoc(mysql_query("SELECT SUM(hits) as hitstoday FROM statistik WHERE tanggal='$tanggal' GROUP BY tanggal")); 
                              $totalhits        = mysql_result(mysql_query("SELECT SUM(hits) FROM statistik"), 0); 
                              $tothitsgbr       = mysql_result(mysql_query("SELECT SUM(hits) FROM statistik"), 0); 
                              $bataswaktu       = time() - 300;
                              $pengunjungonline = mysql_num_rows(mysql_query("SELECT * FROM statistik WHERE online > '$bataswaktu'"));
                              $path1= base_url();
                              //echo $path1;
                              $path = $path1."assets/counter/";
                            //  echo $path;//http://localhost/BP2KP2018/assets/counter/
//echo 'base url'.base_url();
                              $ext = ".png";
//echo "<img src='$path'.2.'$ext' alt='2'>";
                              $tothitsgbr = sprintf("%06d", $tothitsgbr);
                              for ( $i = 0; $i <= 9; $i++ ){

                                 $tothitsgbr = str_replace($i, "<img src='$path$i$ext' alt='$i'>", $tothitsgbr);
                               // $tothitsgbr = str_replace($i, "<img src="'.base_url()."$path$i$ext" alt='$i'>", $tothitsgbr);
                              }

                              echo "<br /><p align=center>$tothitsgbr </p>
                                    <table>
                                    <tr><td class='news-title'><img src=".base_url()."assets/counter/hariini.png> Pengunjung hari ini </td><td class='news-title'> : $pengunjung </td></tr>
                                    <tr><td class='news-title'><img src=".base_url()."assets/counter/total.png> Total pengunjung </td><td class='news-title'> : $totalpengunjung </td></tr>
                                    <tr><td class='news-title'><img src=".base_url()."assets/counter/hariini.png> Hits hari ini </td><td class='news-title'> : $hits[hitstoday] </td></tr>
                                    <tr><td class='news-title'><img src=".base_url()."assets/counter/total.png> Total Hits </td><td class='news-title'> : $totalhits </td></tr>
                                    <tr><td class='news-title'><img src=".base_url()."assets/counter/online.png> Pengunjung Online </td><td class='news-title'> : $pengunjungonline </td></tr>
                                    </table>";
                            ?>
                          </ul>
                       </div>
                       <div id="sidebar2" class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
                          <ul id='listsidebar'>
                            <?php
                            // Tampilkan banner
                            $banner=mysql_query("SELECT * FROM banner ORDER BY id_banner DESC");
                            while($b=mysql_fetch_array($banner)){
                                echo "<p align=center><a href=$b[url] target='_blank' title='$b[judul]'>
                                      <img src='".base_url()."assets/foto_banner/$b[gambar]' border='0' width='150' height='150'><br>$b[judul]</a></p>";
                            }
                          ?>
                          </ul>
                    </div>
              </div>
        </div><!--roe-->



        <hr>
        <div class="row" id="footer"> 
      
           <div class="foot_l"></div>
            <div class="foot_content">
            
             <span class="hid">   <p>Dinas Pangan dan Pertanian Kabupaten Batang</p></span>
             <p>Jl. Ahmad Yani No. 943 Batang  <br />Telp/Fax : (0285)391902<span class="hid">, Email : DPMPTSP@gmail.com</span></p>
            </div>
            <div class="foot_r"></div>
          
        </div>
    <!--/row first child -->
       <!--   <div class="row bawah">-->
		 
          </div> <!--/row bawah-->
	   	

    </div> <!--.container-->

    <script src="<?php echo base_url();?>assets/vendor/jquery/jquery.min.js"></script>
    
    <script src="<?php echo base_url();?>assets/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="<?php echo base_url();?>assets/js/ie10-viewport-bug-workaround.js"></script>

    <script type="text/javascript" src="<?php echo base_url(); ?>assets/DataTables/datatables.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/ie-emulation-modes-warning.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/offcanvas.js"></script>
    
      <script src="<?php echo base_url(); ?>assets/tanggal/js/bootstrap-datepicker.min.js"></script>
       
        <script type="text/javascript">
            $(document).ready(function(){
                $('.data').DataTable(
                  { 
                   "scrollX": true
                }


              );
              


            });


        </script>
 <!--script untuk map-->
           
       
<!-- end: Javascript -->
  </body>
</html>
