<div class="container">
    <form class="cssform" name="property" id="property" method="POST" action="<?php echo base_url('adminer/edtprofil')?>" enctype="multipart/form-data" >
        <h2><a href="#">Update Profil</a></h2>
       <hr>
        <table>
            <tr>
                  <td>  
                      <div class="form-group"> 
                              <label for="profil">Profil Singkat</label> 
                              <textarea name="profil"><?=$rec[0]['latarblg']?></textarea>
                           </div> 
                           <div class="col-md-12 form-group">
                               <label for="file">Update Vidio</label> 
                                 <input type='file' name='video'>
                                 <input type='hidden' name='vid' value='<?=$rec[0]["video"]?>'>
                                <input type='hidden' name='id' value='<?=$rec[0]["id_profil"]?>'>
                           </div>
                 </td>
   
            </tr>
            <tr>
                <td> <input type="submit" name="submit" class="btn btn-md btn-info "  value="Submit" />  <a href="<?=base_url()?>adminer" class="btn btn-danger">
                    <i class="fas fa-arrow-alt-circle-left">Back</i>
                  </a></td>
            </tr>
        </table>
    </form>
</div>