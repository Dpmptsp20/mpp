<script type="text/javascript">
    function perhapus(x){
    s=confirm('Apakah yakin ingin menghapus ?');
    if(s==true){
        window.location.href='<?php echo site_url('adminer/hapus_instansi')?>/'+x;
    }
   }
   
</script>
<div class="col-sm-12 col-md-5 pnlinstansi">
<div class="panel panel-info">
<div class="panel-heading"><h2>Form Tambah Instansi</h2></div>
<div class="panel-body">
<?php echo  $this->session->flashdata('alertpostinstansi');?>
<form action="<?php echo base_url();?>adminer/postinstansi" method="post" role="form"  enctype='multipart/form-data'> 
     <div class="form-group"> 
      <label for="kd">Kode Dinas</label> 
      <input type="text" class="col-md-12 form-control" name="kd"  placeholder="Input kode dinas/instansi"> 
   </div> 
   <div class="form-group"> 
      <label for="nm">Nama Dinas</label> 
      <input type="text" class="col-md-12 form-control" name="nm"  placeholder="Input nama dinas/instansi"> 
   </div> 
    <div class="form-group">
       <label for="berita">Profil Singkat</label> 
          <textarea name='profil'   class="col-md-12 form-control" ></textarea>
   </div>
 
    <div class="form-group"> 
      <label for="name">Link Website</label> 
      <input type="text" class="col-md-12 form-control" name="link"  placeholder="Input link website dinas/instansi"> 
   </div> 
   <div class="col-md-12 form-group">
       <label for="file">Upload Logo</label> 
         <input type=file name='fupload' >
   </div>
   
<div class="form-group"> 
   <button type="submit" name="submit" class="btn btn-sm btn-info btnm">Simpan</button> 
   <button type="button" class="btn btn-sm btn-warning" style="margin-left:10px" onclick="history.back(-1)" >Kembali </button>
</div>
   </form>
</div>
</div>
</div>
<div class="col-sm-12 col-md-7 pnlinstansi1">
<div class="panel panel-info">

   <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h4 class="m-0 font-weight-bold text-primary">Daftar Instansi Tergabung</h4>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="data table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Kd.Dinas</th>
                      <th>Nama Dinas</th>
                      <th>Profil Singkat</th>
                      <th>Website</th>
                      <th>Logo</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                     <th>Kd.Dinas</th>
                      <th>Nama Dinas</th>
                      <th>Profil Singkat</th>
                      <th>Website</th>
                      <th>Logo</th>
                    </tr>
                  </tfoot>
                  <tbody>
                          <?php 
                          $n=1;
                        
                          if($record){
                          foreach($record->result() as $d){
                           $sa=$d->id_instansi;
                            echo '<tr>
                                <td align="center"><span style="font-size:18pt;">'.$d->kd_dinas.'</span><br>
                                   
                  <a href="'.base_url().'adminer/editinstansi/'.$d->id_instansi.'" class="btn btn-warning btn-circle btn-sm">
                      Edit
                    <i class="fas fa-exclamation-triangle"></i>
                  </a>
                  <a href="'.base_url().'adminer/delinstansi/'.$d->id_instansi.'" class="btn btn-danger btn-circle btn-sm">
                    Del
                    <i class="fas fa-trash"></i>
                  </a>
                                </td>
                                <td>'.$d->nm_dinas."</td>
                                <td>".$d->profil."</td>
                                 <td>".$d->website."</td>
                                <td><img src='".base_url()."assets/logo/".$d->logo."' width='100%'></td>
                              </tr>";
                                 
                              $n+=1;
                          }
                          }

                          ?>

                  </tbody>
                </table>
              </div>
            </div>
          </div>
</div>
</div>