<script type="text/javascript">
    function perhapus(x){
    s=confirm('Apakah yakin ingin menghapus ?');
    if(s==true){
        window.location.href='<?php echo site_url('adminer/hapus_instansi')?>/'+x;
    }
   }
   
</script>
<div class="col-sm-12 col-md-5 pnlinstansi">
<div class="panel panel-info">
<div class="panel-heading"><h2>Form Edit Instansi</h2></div>
<div class="panel-body">
<?php echo  $this->session->flashdata('alerteditinstansi');?>
<form action="<?php echo base_url();?>adminer/editinstansi" method="post" role="form"  enctype='multipart/form-data'> 
          <div class="form-group"> 
              <label for="kd">Kode Dinas</label> 
              <input type="text" class="col-md-12 form-control" name="kd" value="<?=$rec1[0]['kd_dinas']?>"  placeholder="Input kode dinas/instansi"> 
           </div> 
           <div class="form-group"> 
              <label for="nm">Nama Dinas</label> 
              <input type="text" class="col-md-12 form-control" name="nm"   value="<?=$rec1[0]['nm_dinas']?>" placeholder="Input nama dinas/instansi"> 
           </div> 
            <div class="form-group">
               <label for="berita">Profil Singkat</label> 
                  <textarea name='profil'   class="col-md-12 form-control" ><?=$rec1[0]['profil']?> </textarea>
           </div>
         
          <div class="form-group"> 
              <label for="name">Link Website</label> 
              <input type="text" class="col-md-12 form-control" name="link"  value="<?=$rec1[0]['website']?>"  placeholder="Input link website dinas/instansi"> 
           </div> 
           <div class="col-md-12 form-group">
            <img src="<?=base_url()?>assets/logo/<?=$rec1[0]['logo']?>" width="150"/>
               <label for="file">Upload Logo</label> 
                 <input type=file name='fuploadup' >
           </div>
              <input type="hidden" class="col-md-12 form-control" name="logo"   value="<?=$rec1[0]['logo']?>">
              <input type="hidden" class="col-md-12 form-control" name="id"   value="<?=$rec1[0]['id_instansi']?>"> 
           
           
        <div class="form-group"> 
           <button type="submit" name="submit" class="btn btn-sm btn-info btnm">Update</button> 
           <button type="button" class="btn btn-sm btn-warning" style="margin-left:10px" onclick="history.back(-1)" >Kembali </button>
        </div>
   </form>
</div>
</div>
</div>
<div class="col-sm-12 col-md-7 pnlinstansi1">
<div class="panel panel-info">

   <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h4 class="m-0 font-weight-bold text-primary">Daftar Instansi Tergabung</h4>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="data table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Kd.Dinas</th>
                      <th>Nama Dinas</th>
                      <th>Profil Singkat</th>
                      <th>Website</th>
                      <th>Logo</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                     <th>Kd.Dinas</th>
                      <th>Nama Dinas</th>
                      <th>Profil Singkat</th>
                      <th>Website</th>
                      <th>Logo</th>
                    </tr>
                  </tfoot>
                  <tbody>
                          <?php 
                          $n=1;
                        
                          if($record){
                          foreach($record->result() as $d){
                           $sa=$d->id_instansi;
                            echo '<tr>
                                <td align="center"><span style="font-size:18pt;">'.$d->kd_dinas.'</span><br>
                                   
                  <a href="'.base_url().'adminer/editinstansi/'.$d->id_instansi.'" class="btn btn-warning btn-circle btn-sm">
                      Edit
                    <i class="fas fa-exclamation-triangle"></i>
                  </a>
                  <a href="'.base_url().'adminer/delinstansi/'.$d->id_instansi.'" class="btn btn-danger btn-circle btn-sm">
                    Del
                    <i class="fas fa-trash"></i>
                  </a>
                                </td>
                                <td>'.$d->nm_dinas."</td>
                                <td>".$d->profil."</td>
                                 <td>".$d->website."</td>
                                <td><img src='".base_url()."assets/logo/".$d->logo."' width='100%'></td>
                              </tr>";
                                 
                              $n+=1;
                          }
                          }

                          ?>

                  </tbody>
                </table>
              </div>
            </div>
          </div>
</div>
</div>