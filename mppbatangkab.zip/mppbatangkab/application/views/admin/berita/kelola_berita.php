<script type='text/javascript'>
function perhapus(x){
	
	s=confirm('Apakah yakin ingin menghapus');
	if(s==true){
		//alert('<?php echo site_url('adminer/hapus_berita')?>/'+x);
		window.location.href='<?php echo site_url("adminer/hapus_berita")?>/'+x;
	}
}

</script>



<!-- input berita-->
<div class="row">
<div class="col-md-12" style="width:1350px;margin-left:15%;text-align:center;color:blue">
		<h4>	<?= $this->session->flashdata('pesankelolaberita');?></h4>
		</div>
</div>
<div class="row">
<div class="col-sm-12 col-md-5 pnlinstansi1">
<div class="panel panel-info">
<div class="panel-heading"><h2>Tambah Artikel</h2></div>
<div class="panel-body">

<form action="<?php echo base_url();?>adminer/posberita" method="post" role="form"  enctype='multipart/form-data'> 
   <div class="form-group"> 
      <label for="name">Judul</label> 
      <input type="text" class="form-control" name="judul"  placeholder="Enter Name"> 
   </div> 
 
   <div class="form-group">
       <label for="berita"> Isi Berita</label> 
          <textarea name='isi_berita'   class="col-md-5 form-control" ></textarea>

   </div>
   <div class="form-group">
       <label for="gambar"> Gambar</label> 
         <input type=file name='fupload' >
          <br>Tipe gambar harus JPG/JPEG/GIF/PNG dengan ukuran maxs 100 dan ukuran lebar maks: 400 px


   </div>
<div class="form-group"> 
   <button type="submit" name="submit" class="btn btn-info btnm">Simpan</button> 
  
  <!-- <a href="<?php echo base_url();?>adminer/kelolaDok" class="anchadm">Kelola Data Dokter</a>-->
  
</div>
   </form>
</div>
</div>
</div>


<div class="col-sm-12 col-md-7 pnlinstansi1">
<div class="panel panel-info">
		<div class="col-sm-3 full-right">
			<a class="btn btn-sm btn-info" href="<?php echo base_url()?>adminer/addberita" >Tambah Artikel</a>
		</div>
		


<hr/>
<table class="data table-bordered"  width="100%" cellspacing="0">
<thead>
<tr>
	<th width='5%'>No</th>
	<th><center>Judul</center></th>
	<th align="center">Tgl_Posting</th> 
	<th><center>Tampil</center></th>
	<th><center>setting</center></th>
</tr>
</thead>
<tbody>
<?php 
$n=1;
if($record){
	foreach($record->result() as $d){
		//$z=base_url()."admin/editdok/".$d->id_berita;
$st=$d->status==1?'Ya':'tidak';
	$tgl_s=explode('-',$d->tanggal);
	$tgl_now=$tgl_s[2].'-'.$tgl_s[1].'-'.$tgl_s[0];
	$sa=$d->id_berita;
	
		echo '<tr>
				<td>'.$n.'</td>
				<td>'.$d->judul.'</td>
				<td>'.$tgl_now.'</td<td>
				<td>'.$st.'</td>
				<td>'.anchor("adminer/editberita/".$d->id_berita,' Edit',array('class'=>'fa fa-edit anch')).'
					<a onclick="perhapus('.$sa.')" id="an" class="fa fa-remove anch"><i> Hapus</i></a>
				 </td>
		
			
			
				
			</tr>';
			$n+=1;
	}
}
?>
	
</tbody>
</table>
</div>
</div>
</div>