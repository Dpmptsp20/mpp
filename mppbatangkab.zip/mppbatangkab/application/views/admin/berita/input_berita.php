
<div class="col-sm-12 col-md-12">
<div class="panel panel-info">
<div class="panel-heading"><h2>Tambah Artikel</h2></div>
<div class="panel-body">
<?php echo  $this->session->flashdata('alertberita');?>
<form action="<?php echo base_url();?>adminitr/posberita" method="post" role="form"  enctype='multipart/form-data'> 
   <div class="form-group"> 
      <label for="name">Judul</label> 
      <input type="text" class="form-control" name="judul"  placeholder="Enter Name"> 
   </div> 
   <div class="form-group"> 
      <label for="name">Ketegori</label> 
    <select  name="kategori" class="form-control"> 
            <?php 
            //$tampil=mysql_query("SELECT * FROM kategori where id_kategori<>30 ORDER BY nama_kategori");
              $c=count($rkat);
         for($i=0;$i<$c;$i++){
            if ($record[0]['id_kategori']==$rkat[$i]['id_kategori']){
              echo "<option value='".$rkat[$i]['id_kategori']."' selected>".$rkat[$i]['nama_kategori']."</option>";
            }
            else{
              echo "<option value='".$rkat[$i]['id_kategori']."' selected>".$rkat[$i]['nama_kategori']."</option>";
           
            }
          }
              ?>
      </select>
   </div>
    <div class="form-group"> 
        <label  for="headline"> Headline</label> 
         <!-- <input type=radio name='headline' value='Y' checked>Y 
           <input type=radio name='publish' value='N'> N-->
          <div class="radio-inline">
              <!-- <label class="col-md-offset-2"><input type="radio" name='hl' value="Y" />Y</label>-->
               <input type=radio name='hl' value="Y" checked> Y
         </div>
         <div class="radio-inline">
             <!--  <label><input type="radio" name='hl' value="N" /> N </label>-->
<input type=radio name='hl' value="N" > N 
          </div>
   </div> 
   <div class="form-group">
       <label for="berita"> Isi Berita</label> 
          <textarea name='isi_berita'   class="col-md-5 form-control" ></textarea>

   </div>
   <div class="form-group">
       <label for="gambar"> Gambar</label> 
         <input type=file name='fupload' >
          <br>Tipe gambar harus JPG/JPEG/GIF/PNG dengan ukuran maxs 100 dan ukuran lebar maks: 400 px


   </div>
    <div class="form-group">
     <?php  $tag = mysql_query("SELECT * FROM tag ORDER BY tag_seo");
    echo "<tr><td>Tag (Label)</td><td> ";
    while ($t=mysql_fetch_array($tag)){
      echo "<label class='checkbox-inline'><input type='checkbox' name=tag_seo[] value='$t[tag_seo]'>$t[nama_tag] </label>";
    }


    ?>
   </div>
<div class="form-group"> 
   <button type="submit" name="submit" class="btn btn-info btnm">Simpan</button> 
  
  <!-- <a href="<?php echo base_url();?>adminitr/kelolaDok" class="anchadm">Kelola Data Dokter</a>-->
  
</div>
   </form>
</div>
</div>
</div>