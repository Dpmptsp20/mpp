
<div class="col-sm-12 col-md-12">
<div class="panel panel-info">
<div class="panel-heading"><h2>Edit Artikel</h2></div>
<div class="panel-body">
<?php echo  $this->session->flashdata('alertberita');?>
<form action="<?php echo base_url();?>adminitr/updateberita" method="post" role="form"  enctype='multipart/form-data'> 
<input type=hidden name=id value="<?php echo $record[0]['id_berita']?>">
   <div class="form-group"> 
      <label for="name">Judul</label> 
      <input type="text" class="form-control" name="judulup"   value="<?php echo $record[0]['judul']; ?>"> 
   </div> 
   <div class="form-group"> 
      <label for="name">Ketegori</label> 
      <select  name="kategori" class="form-control"> 
            <?php 
            //$tampil=mysql_query("SELECT * FROM kategori where id_kategori<>30 ORDER BY nama_kategori");
              $c=count($rkat);
         for($i=0;$i<$c;$i++){
            if ($record[0]['id_kategori']==$rkat[$i]['id_kategori']){
              echo "<option value='".$rkat[$i]['id_kategori']."' selected>".$rkat[$i]['nama_kategori']."</option>";
            }
            else{
              echo "<option value='".$rkat[$i]['id_kategori']."' selected>".$rkat[$i]['nama_kategori']."</option>";
           
            }
          }
              ?>
      </select>
   </div>
   <?php
  echo' <div class="form-group">';
   if($record[0]['status']=='1'){

    echo '<label>Tampilkan</label>
            <div class="radio-inline">
             <input type="radio" name="status" value="1" checked>Ya
              </div>
               <div class="radio-inline">
              <input type="radio" name="status" value="0">Tidak
          </div>
    </div>';
    }
  else{
echo '<label>Tampilkan</label>
            <div class="radio-inline">
             <input type="radio" name="status" value="1">Ya
              </div>
              <div class="radio-inline">
              <input type="radio" name="status" value="0" checked>Tidak
             </div>
    </div>';

    }


    //headline    
   if ($record[0]['headline']=='Y'){
      echo " <div class='form-group'> 
                   <label  for='headline'> Headline</label> 
                    <div class='radio-inline'>
                       <input type=radio name='headline' value='Y' checked>Ya
                    </div>
                    <div class='radio-inline'>
                        <input type=radio name='headline' value='N'>Tidak
                    </div>";

    }else{
     echo " <div class='form-group'> 
                   <label  for='headline'> Headline</label> 
                    <div class='radio-inline'>
                       <input type=radio name='headline' value='Y'>Ya
                    </div>
                    <div class='radio-inline'>
                        <input type=radio name='headline' value='N'  checked>Tidak
                    </div>";
      }
    ?>

      <div class="form-group">
       <label for="berita"> Isi Berita</label> 
          <textarea name='isi_berita'   class="form-control" > <?php echo $record[0]['isi_berita']; ?></textarea>

   </div>
  <?php 

  if ($record[0]['gambar']!=''){
     
      $gma='assets/foto_berita/small_'.$record[0]['gambar'];
       $gm= base_url().$gma;
       $gmlh=$record[0]['gambar'];
      //$egm=explode('.',$gm);

     // $tgm=$egm[0].'_thumb';#http://localhost/DISPERPAN/assets/foto_berita/small_39daging.jpg

          echo "<img src='".$gm."' width='80' height='50' >";  
          }
    ?>
    <input type="hidden" name="namagambar" value="<?=$gmlh?>" >
   <div class="form-group">
       <label for="gambar"> Gambar</label> 
         <input type=file name='fuploadup' >
          <br>Tipe gambar harus JPG/JPEG/GIF/PNG dengan ukuran maxs 100 dan ukuran lebar maks: 400 px


   </div>
    <div class="form-group">
    <?php /* $tag = mysql_query("SELECT * FROM tag ORDER BY tag_seo");
       echo "<tr><td>Tag (Label)</td><td> ";
       while ($t=mysql_fetch_array($tag)){
         echo "<label class='checkbox-inline'><input type='checkbox' name=tag_seo[] value='$t[tag_seo]'>$t[nama_tag] </label>";
       }*/
 $d = GetCheckboxes('tag', 'tag_seo', 'nama_tag', $record[0]['tag']);

    echo "Tag (Label) <label class='checkbox-inline'> $d </label>";
 

    ?>
   </div>
<div class="form-group"> 
   <button type="submit" name="submit" class="btn btn-info btnm">Update</butpton> 
  
  <!-- <a href="<?php echo base_url();?>adminitr/kelolaDok" class="anchadm">Kelola Data Dokter</a>-->
  
</div>
   </form>
</div>
</div>
</div>