<!DOCTYPE html>
<html lang="en" class="no-js bg-color-sky-light">
    <head>
        <meta charset="utf-8"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>DPMPTSP & NAKER Kabupaten Batang</title>
        <link href='<?php echo base_url(); ?>assets/img/favicon.ico' rel='shortcut icon' type='image/x-icon'/>
        <!-- Mobile Metas -->
        <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <!-- GLOBAL MANDATORY STYLES -->
        <link href="<?php echo base_url(); ?>font/fontGoogle.css" rel='stylesheet' type='text/css'>      
        <link href="<?php echo base_url(); ?>assets/css/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo base_url(); ?>assets/plugins/et-line/et-line.css" rel="stylesheet" type="text/css"/>
        <!-- END GLOBAL MANDATORY STYLES -->

        <!-- BEGIN THEME PLUGINS STYLE -->
        <link href="<?php echo base_url(); ?>assets/css/animate.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo base_url(); ?>assets/css/style-switcher.css" rel="stylesheet" type="text/css"/>
        <!-- GLOBAL THEME STYLES -->
        <link href="<?php echo base_url(); ?>assets/css/global.css" rel="stylesheet" type="text/css"/>
        <!-- THEME STYLES
        <link href="<?php echo base_url(); ?>assets/css/landing.css" rel="stylesheet" type="text/css"/> -->
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/jquery.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                if ($('#register-form-tipe').val() == 'Perorangan') {
                    //document.getElementById('register-form-npwp').value = '';
                    $('#npwp').hide();
                    $('#name_perus').hide();                    
                } else if ($('#register-form-tipe').val() == 'Perusahaan') {
                    $('#ktp').hide();
                    $('#name').hide();
                }
                $('#register-form-tipe').change(function () {
                    if ($('#register-form-tipe').val() == 'Perorangan') {
                        $('#npwp').hide();
                        $('#name_perus').hide();
                        $('#ktp').show();
                        $('#name').show();
                    } else if ($('#register-form-tipe').val() == 'Perusahaan') {
                        $('#npwp').show();
                        $('#name_perus').show();
                        $('#ktp').hide();
                        $('#name').hide();

                    }
                });
            });

        </script>
    </head>
    <!-- END HEAD -->
    <!-- BODY -->
    <body class="bg-color-sky-light">
        <!-- WRAPPER -->

        <div class="wrapper animsition">           
            <!-- Landing Login -->
            <div class="l-login center-block">
                <div class="content-md container-sm">
                    <!-- Login Content -->
                    <div class="l-login-content center-block radius-5 margin-b-30">
                        <!-- Login Form Logo -->
                        <div class="margin-b-40">
                            <a href="">
                                <img class="l-login-logo" src="<?php echo base_url(); ?>assets/img/logo-login.png" alt="PTSP">
                            </a>
                        </div>
                        <!-- End Login Form Logo -->

                        <!-- Login Form -->
                        <?php
                        echo form_open('auth/login', 'class="login-form"');
                        if (validation_errors() || $this->session->flashdata('error')) {
                            ?>
                            <?php echo "<p class='text-danger' >" . validation_errors() . "</p>" ?>                                        
                            <?php echo "<p class='text-danger' >" . $this->session->flashdata('error') . "</p>" ?>                                               

                        <?php } ?>  
                        <?php echo $this->session->flashdata('message'); ?>
                        <div class="form-group">
                            <input class="form-control radius-50" type="email" autocomplete="on" placeholder="Username or Email" name="username"/>
                        </div>
                        <div class="form-group">
                            <input class="form-control radius-50" type="password" autocomplete="on" placeholder="Password" name="password"/>
                        </div>
                        <div class="margin-b-20">
                            <button type="submit" class="btn-base-bg btn-base-sm btn-block radius-50">Sign In</button>
                        </div>
                        <p class="font-size-14">
                            <a href="javascript:;" id="forgot-password">Lupa Password?</a>
                        </p>
                        <p>
                            Belum Punya Akun?
                            <a href="javascript:;" id="go-to-signup-form-btn" >DAFTAR DISINI</a>
                        </p>
                        <p>                           
                            <a href="<?php echo base_url('site'); ?>" id="go-to-signup-form-btn">Back Home</a>
                        </p>
                        </form>
                        <!-- End Login Form -->

                        <!-- Forgot Password Form -->
                        <?php echo form_open('auth/reset_password', 'class="forgot-password-form forgot-password-form display-none"'); ?>                       
                        <div class="form-group">
                            <input class="form-control radius-50" type="text" autocomplete="on" placeholder="Email" name="email"/>
                        </div>
                        <div class="margin-b-20">
                            <button type="submit" class="btn-base-bg btn-base-sm btn-block radius-50">Reset Password</button>
                        </div>
                        <div class="create-account">
                            <p>
                                Sudah Punya Akun?
                                <a href="javascript:;" id="back-btn">Login</a>
                            </p>
                        </div>
                        </form>
                        <!-- End Forgot Password Form -->

                        <!-- Signup Form perorangan-->
                        <?php echo form_open('auth/register', 'class="signup-form signup-form display-none"'); ?>
                        <div class="form-group">
                            <select class="form-control radius-50" id="register-form-tipe" name="register-form-tipe">
                                <option value="Perorangan">Perorangan</option>
                                <option value="Perusahaan">Perusahaan</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <input class="form-control radius-50 pesan-ktp" type="number" id="ktp" placeholder="No KTP" name="ktp"/>
                        </div>
                        <div class="form-group">
                            <input class="form-control radius-50 pesan-npwp" type="number" id="npwp" placeholder="NPWP Perusahaan" name="npwp"/>
                        </div>
                        <div class="form-group">
                            <input class="form-control radius-50 pesan-perus" type="text" id="name_perus" placeholder="Nama Perusahaan" name="name_perus"/>
                        </div>
                        <div class="form-group">
                            <input class="form-control radius-50 pesan-nama" type="text" id="name" placeholder="Nama Sesuai KTP" name="name"/>
                        </div>
                        <div class="form-group">
                            <input class="form-control radius-50" type="text" id="email" placeholder="Email" name="email"/>
                        </div>
                        <div class="form-group">
                            <input class="form-control radius-50" type="number" autocomplete="on" id="handphone" placeholder="No Handphone" name="handphone"/>
                        </div>
                        <div class="form-group">
                            <input class="form-control radius-50" type="password" autocomplete="on" id="signup_password" placeholder="Password" name="password"/>
                        </div>
                        <div class="form-group">
                            <input class="form-control radius-50" type="password" autocomplete="on" id="confirm_password" placeholder="Confirm Password" name="confirm_password"/>
                        </div>
                        <div class="margin-b-30">
                            <p class="font-size-14">

                            </p>
                        </div>
                        <div class="margin-b-20">
                            <button type="submit" id="signup-submit-btn" name="daftar" class="btn-base-bg btn-base-sm btn-block radius-50">Daftar</button>
                        </div>
                        <p>
                            Sudah Punya Akun?
                            <a href="javascript:;" id="back-to-login-form-btn">Login</a>
                        </p>
                        </form>
                        <!-- End Signup Form -->
                    </div>
                    <!-- End Login Content -->

                    <p class="font-size-14 margin-b-0">&#169; 2020 | MPP Kabupaten Batang </p>
                </div>
                <!-- End Landing Login -->
            </div>
            <!-- End Landing Login -->
            <!--========== END LANDING PAGE CONTENT ==========-->
        </div>
        <!-- END WRAPPER -->

        <!-- Sidebar Content Overlay -->
        <div class="sidebar-content-overlay"></div>
        <!-- End Sidebar Content Overlay -->

        <!-- CORE PLUGINS -->
        <script type="text/javascript" src="<?php echo base_url('themes/js/jQuery-2.1.4.min.js') ?>"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/jquery.migrate.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <!-- END CORE PLUGINS -->

        <!-- PAGE LEVEL PLUGINS -->
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/jquery.animsition.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/jquery.wow.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/validation/jquery.validate.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/validation/additional-methods.min.js"></script>
        <!-- END PAGE LEVEL PLUGINS -->

        <!-- GLOBAL PAGE LEVEL SCRIPTS -->
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/scripts/app.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/scripts/components/style-switcher.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/scripts/components/animsition.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/scripts/components/wow.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/vendor/login-form.js"></script>
        <!-- END GLOBAL PAGE LEVEL SCRIPTS -->

        <!-- LANDING PAGE LEVEL SCRIPTS -->



    </body>
    <!-- END BODY -->

</html>
