<!DOCTYPE html>
<html lang="en" class="no-js bg-color-sky-light">
    <head>
        <meta charset="utf-8"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>DPMPTSP & NAKER Kabupaten Batang</title>
        <link href='<?php echo base_url(); ?>assets/img/favicon.ico' rel='shortcut icon' type='image/x-icon'/>
        <!-- Mobile Metas -->
        <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <!-- GLOBAL MANDATORY STYLES -->
        <link href="<?php echo base_url(); ?>font/fontGoogle.css" rel='stylesheet' type='text/css'>      
        <link href="<?php echo base_url(); ?>assets/css/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo base_url(); ?>assets/adminmpp.css" rel="stylesheet" type="text/css"/>
        <!-- END GLOBAL MANDATORY STYLES -->

        <!-- BEGIN THEME PLUGINS STYLE 
        <link href="<?php echo base_url(); ?>assets/css/animate.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo base_url(); ?>assets/css/adm/css/sb-admin-2.css" rel="stylesheet" type="text/css"/>-->
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/jquery.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                if ($('#register-form-tipe').val() == 'Perorangan') {
                    //document.getElementById('register-form-npwp').value = '';
                    $('#npwp').hide();
                    $('#name_perus').hide();                    
                } else if ($('#register-form-tipe').val() == 'Perusahaan') {
                    $('#ktp').hide();
                    $('#name').hide();
                }
                $('#register-form-tipe').change(function () {
                    if ($('#register-form-tipe').val() == 'Perorangan') {
                        $('#npwp').hide();
                        $('#name_perus').hide();
                        $('#ktp').show();
                        $('#name').show();
                    } else if ($('#register-form-tipe').val() == 'Perusahaan') {
                        $('#npwp').show();
                        $('#name_perus').show();
                        $('#ktp').hide();
                        $('#name').hide();

                    }
                });
            });

        </script>
    </head>
    <!-- END HEAD -->
    <!-- BODY -->
    <body class="conlog">

    	<div class="contenlog">
<form action="<?php echo base_url();?>statistic_c/log" class="form-horizontal" method="post">

<table class="table table-bordered">
<tr class="success">
	<td colspan=2 align="center"><h3><font color="black" >Form Login Admin</font></h3></td>
	
</tr>
<tr>
<td>
<p>
<div class="form-group">
<label class="control-label col-sm-3 col-sm-offset-1">User Name :</label>
<div class="col-md-6">
	  <input type="text" name="username" class="form-control" placeholder="Username admin" aria-describedby="sizing-addon2">
</div>
</div>
<div class="form-group">
<label class="control-label col-sm-3 col-sm-offset-1">Password :</label>
<div class="col-md-6">
	  <input type="password" name="password" class="form-control" placeholder="Password admin" aria-describedby="sizing-addon2" required>
</div>
</div>

<input type="hidden" name="adm" value="adm">
<div class="form-group">
<div class="col-sm-4 col-md-4 col-sm-offset-3">
      <Button type="submit" class="btn btn-danger" name="submit" style="margin-top:5px;margin-right:10px">Login</button>

      <Button type="reset" class="btn btn-default" name="reset" style="margin-top:5px">Batal</button>
</div>

</div>
</p>
</td>
</tr>




</table>
</form>
</div>

    </body>
    <!-- END BODY -->

</html>
