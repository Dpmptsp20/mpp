<div class="row col-md-12">
<div class="col-ms-12 col-md-10">

	<style type="text/css">
		body{
			font-family: roboto;
		}
	</style>

 	<?php
 if($datagr){
  echo'

	<h2>Grafik Surver Kepuasan Masyarakat</h2>
	<center> <a href="'.base_url().'adminer/resetskm/" class="btn btn-danger btn-md">
                 Setting Ulang Data SKM 
                     <i class="fas fa-undo"></i> 
                  </a> </center>
	<div class="col-md-12">
		<canvas id="myChart"></canvas>
	</div>
 	<div  class="col-md-12">
	<canvas id="myChartb"></canvas>
	</div>
';
}else{
	echo 'tanpa data';
}

?>
<div id="outpu">

</div>

</div></div>