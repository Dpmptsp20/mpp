
<!-- input saran-->
<div class="col-md-12" style="margin-left:15%;text-align:center;color:blue">
		<h4>	<?= $this->session->flashdata('pesankelolasaran');?></h4>
		</div>
</div>

<div id="intang"></div>
<div class="row">


<div class="col-sm-12 col-md-12">


<hr/>
<table class="data table-bordered"  width="100%" cellspacing="0">
<thead>
<tr>
	<th width='2%'>No</th>
	<th width='16%'><center>Nama (Email)</center></th>
	<th  width='5%'align="center">Jenis</th> 
	<th width='30%'><center>Pesan</center></th>
	<th><center>Jawaban</center></th>
	<th  width='6%'><center>Tanggal</center></th>
	<th width='10%'><center>setting</center></th>
</tr>
</thead>
<tbody>
<?php 
$n=1;
$id='';
if($record){
	foreach($record->result() as $d){
		//$z=base_url()."admin/editdok/".$d->id_saranadu;
		$idr=$d->id_respon;

	$sap=$d->id_saranadu.'/'.$idr;
		$j=$d->respon;
		if($j!=""){
			$j=$d->respon;
			$j.='<a href="'.base_url().'adminer/editrespon/'.$idr.'"><i class="fa fa-edit"> Edit Respons</i></a>';
				$j.='  ||  <a href="'.base_url().'adminer/hapus_respon/'.$idr.'"><i class="fa fa-trash"> Delete Respons</i></a>';
		}else{
			$j="Belum ada respon";
		}

	$tgl_s=explode('-',$d->tanggal);
	$tgl_now=$tgl_s[2].'-'.$tgl_s[1].'-'.$tgl_s[0];
	$sa=$d->id_saranadu;
		echo '<tr>
				<td>'.$n.'</td>
				<td>'.$d->nama.'<br> (<a href="mailto:'.$d->email.'?Subject=Hello%20again" target="_top">Kirim Mail : '.$d->email.'</a>)</td>
				<td>'.$d->jenis.'</td>
				<td>'.$d->pesan.'</td>
				<td>'.$j.'</td>
				<td>'.$tgl_now.'</td>
				<td>
				<a href="'.base_url().'adminer/hapus_saran/'.$sap.'"><i class="fa fa-edit"> Hapus</i></a> ';
			if($idr==""){
				echo'<a onclick="inta('.$sa.')" href="#" class="fa fa-reply "> <i class="fa fa-file-pdf-o">Respons</i></a>';
			}		
				
			echo'	 </td>
			</tr>';
			$n+=1;
	}
}
?>
	
</tbody>
</table>

</div>
   
<!--Modal HTML -->
<div id="myModal"  class="modal fade">
    <div class="modal-dialog" style="background-color: white;width: 65%">


 <section class="breadcrumbs-v1">
    <div class="container">
        <ol class="breadcrumb">
            <li><a href="<?=base_url();?>">Home</a></li>
            <li><a href="#">Page</a></li>
            <li class="active">informasi <?=$ket?></li>
        </ol>
         <button type="button" class=" btn-sm btn-danger" style="position:relative;margin-left: 93%" data-dismiss="modal">
                <i class="fa fa-close"> Keluar</i></button>
    </div>
</section>
<section class="content">
    <div class="container">
        <div class='box-body' >
         <h4><a>Input Response</a><h4>
             
            <center>
          
            <br>
       <textarea name="response"></textarea> 
        </center>  
        </div>          
    </div>
</section>

</div>

</div>







    </div>
<script type='text/javascript'>
function perhapus(x){
	
	s=confirm('Apakah yakin ingin menghapus');
	if(s==true){
		//alert('<?php echo site_url('adminer/hapus_saran')?>/'+x);
		window.location.href='<?php echo site_url("adminer/hapus_saran")?>/'+x;
	}
}
function inta(xl){
	var ind='<div id="intange"><form action="<?php echo base_url();?>adminer/tanggapan" method="post" role="form"  enctype="multipart/form-data"><center> <textarea name="tanggapan" cols="150" rows="2" placeholder="Form Input Response"></textarea><input type="hidden" name="id" value="'+xl+'"><div class="form-group"> <button type="submit" name="submit" class="btn btn-sm btn-info btnm">Simpan</button> <button type="button"  onclick="btal()" class="batal btn btn-sm btn-warning " style="margin-left:10px" >Batal</button></div> </form></center></div>';
                    document.getElementById("intang").innerHTML = ind;

}
function btal(){
	//	alert('oke dsi');
                  document.getElementById("intange").remove();
                 
}

        /*    $(function () {
                $(document).on('click', '.edit-record', function (e) {
                    e.preventDefault();
                    $("#myModal").modal('show');
                 
                });
            });*/
 </script>
  