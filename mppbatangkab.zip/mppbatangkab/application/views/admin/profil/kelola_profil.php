<div class="indprofil">
<div class="col-ms-12 col-md-12">

<?= $this->session->flashdata('pesankelolaprofil');?>
<table class="table table-striped">
<tr  class="danger">
<th><center>Profil MPP</center></th><th><center>setting</center></th>

<tr>
			<td><p class="kprofil" align='justify'>
				<video class='vidprofil' controls>
					<?php $ddt=$rec!=null?$rec[0]['video']:'mpp.mp4'; ?>
					<source src='<?php echo base_url();?>assets/vidio/<?=$ddt?>' type='video/mp4'>
					<source src='<?php echo base_url();?>assets/vidio/<?=$ddt?>'  type='video/ogg'>
				</video>
					<?php $dd=$rec!=null?$rec[0]['latarblg']:' '; ?> <?=$dd ?>
				</p>
			</td>

			<td><?= anchor("adminer/edtprofil/".$rec[0]['id_profil'],'Edit',array('class'=>'fa fa-edit anch')) ?></td>
</tr>

</table>
</div>
</div>