
<div class="row col-md-12">
	<?php $this->load->view($view1); ?>
<div class="col-ms-12 col-md-6">

<?= $this->session->flashdata('pesankeloladownload');?>
<table class="table table-striped">
<tr><td colspan="4"></td><td colspan=2><a class="btn btn-sm btn-info" href="<?php echo base_url()?>adminer/kelola_download" >Upload File</a></td>
<tr  class="danger">
<th width='5%'>No</th><th><center>Judul</center></th><th><center>Nama File</center></th><th align="center">Tgl_Posting</th><th colspan=2 width='10%' ><center>setting</center></th>
</tr>
<?php 
$n=1;

if($record){
foreach($record->result() as $d){
 $tgl_s=explode('-',$d->tgl_posting);
$tgl_now=$tgl_s[2].'-'.$tgl_s[1].'-'.$tgl_s[0];
$sa=$d->id_download;
//.'-'.$d->gambar
	echo "<tr>
			<td>".$n."</td>
			<td>".$d->judul."</td>
			<td>".$d->nama_file."</td>
			<td>".$tgl_now."</td>

			<td>".anchor("adminer/editdownload/".$sa,'Edit',array('class'=>'anch')).' </td>
			<td>
			<a class="anch" onclick="perhapus('.$sa.')" id="an" >Hapus</a>
			</td>
		</tr>';
				//anchor("admin/hapusdok/".$d->id_dokter,'Hapus',array('class'=>'x anch','onclick'=>'perhapus()')) href="'.$z.'"
		$n+=1;
}
}
;
?>




</table>
</div>

</div>