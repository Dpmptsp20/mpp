<script type="text/javascript">
	  function perhapus(x){
    s=confirm('Apakah yakin ingin menghapus ?');
    if(s==true){
        window.location.href='<?php echo site_url('adminitr/hapus_download')?>/'+x;
    }
   }
   
</script>




<div class="col-sm-12 col-md-6">
<div class="panel panel-info">
<div class="panel-heading"><h2>Upload File</h2></div>
<div class="panel-body">
<?php echo  $this->session->flashdata('alertdownload');?>
<form action="<?php echo base_url();?>adminer/posdownload" method="post" role="form"  enctype='multipart/form-data'> 
   <div class="form-group"> 
      <label for="name">Judul</label> 
      <input type="text" class="form-control" name="judul"  placeholder="Enter Keterangan File Download"> 
   </div> 
   <div class="form-group">
       <label for="file"> File</label> 
         <input type=file name='fupload' required="required">
   </div>
   
<div class="form-group"> 
   <button type="submit" name="submit" class="btn btn-info btnm">Simpan</button> 
   <button type="button" class="btn btn-warning" style="margin-left:10px" onclick="history.back(-1)" >Kembali </button>
 
  <!-- <a href="<?php echo base_url();?>adminitr/kelolaDok" class="anchadm">Kelola Data Dokter</a>-->
  
</div>
   </form>
</div>
</div>
</div>