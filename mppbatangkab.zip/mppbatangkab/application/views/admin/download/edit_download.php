
<div class="col-sm-12 col-md-6">
<div class="panel panel-info">
<div class="panel-heading"><h2>Edit Download</h2></div>
<div class="panel-body">
<?php echo  $this->session->flashdata('alertdownload');?>
<form action="<?php echo base_url();?>adminer/updatedownload" method="post" role="form"  enctype='multipart/form-data'> 
<input type='hidden' name='id' value="<?php echo $record1[0]['id_download']?>">
   <div class="form-group"> 
      <label for="name">Judul</label> 
      <input type="text" class="form-control" name="judul" value="<?php echo $record1[0]['judul']; ?>"> 
   </div> 
  
   <div>Ganti File: </div>
 <?php 

  if ($record1[0]['nama_file']!=''){
       $gmlh=$record1[0]['nama_file'];
          echo "<br><p>$gmlh</p><br>Apabila tidak diganti, maka cukup di PHP saja.";  
          }
    ?>
   <div class="form-group">
       <label for="file"> File</label> 
         <input type=file name='fuploadup'>
   </div>
    <input type="hidden" name="namafile" value="<?=$record1[0]['nama_file']?>" >
<div class="form-group"> 
   <button type="submit" name="submit" class="btn btn-info btnm">Update</butpton> 
   <button type="button" class="btn btn-warning" style="margin-left:10px" onclick="history.back(-1)" >Kembali </button>
 
</div>
   </form>
</div>
</div>
</div>