<script type="text/javascript">
    function perhapuslay(x){
    s=confirm('Apakah yakin ingin menghapus ?');
    if(s==true){
        window.location.href='<?php echo site_url('adminer/dellayanan')?>/'+x;
    }
   }
   
</script>
<div class="col-sm-12 col-md-5 pnlinstansi">
<div class="panel panel-info">
<div class="panel-heading"><h2>Form Tambah Layanan Instansi</h2></div>
<div class="panel-body">
<?php echo  $this->session->flashdata('alertpostlayanan');?>
<form action="<?php echo base_url();?>adminer/postlayanan" method="post" role="form"  enctype='multipart/form-data'> 
    <div class="form-group"> 
    <label for="ins">Pilih Instansi</label> 
    <select  name="ins" class="form-control"> 
      <option>==:> Pilih Instansi <:==</option>
            <?php 
            //$tampil=mysql_query("SELECT * FROM kategori where id_instansi<>30 ORDER BY nm_dinas");
              $c=count($rkat);
         for($i=0;$i<$c;$i++){
                    echo "<option value='".$rkat[$i]['id_instansi']."'>".$rkat[$i]['nm_dinas']."</option>";
             }
              ?>
    </select>
      </div> 
   <div class="form-group"> 
      <label for="nm">Nama Layanan</label> 
      <input type="text" class="col-md-12 form-control" name="nm"  placeholder="Input nama layanan"> 
   </div> 
   <div class="form-group"> 
      <label for="biaya">Biaya</label> 
      <input type="text" class="col-md-12 form-control" name="biaya"  placeholder="Input biaya layanan"> 
   </div> 

    <div class="form-group">
       <label for="waktu">Jangka Waktu</label> 
       
      <input type="text" class="col-md-12 form-control" name="waktu"  placeholder="Input jangka waktu layanan"> 
   </div>
 <div class="form-group"> 
      <label for="dasar_hukum">Dasar Hukum</label> 
      <textarea name='dasar_hukum' class="col-md-12 form-control" ></textarea>
   </div> 
    <div class="form-group"> 
      <label for="prosedur">Prosedur</label> 
      <textarea name='prosedur' class="col-md-12 form-control" ></textarea>
   </div> 
   <div class="form-group"> 
      <label for="name">Syarat</label> 
      <textarea name='syarat' class="col-md-12 form-control" ></textarea>
   </div> 
   <div class="form-group"> 
      <label for="penjelasan">Penjelasan</label> 
      <textarea name='penjelasan' class="col-md-12 form-control" ></textarea>
   </div> 
   <div class="form-group"> 
      <label for="link">Link</label> 
      <input type="text" class="col-md-12 form-control" name="link"  placeholder="Input Link layanan"> 
   </div> 
<div class="form-group"> 
   <button type="submit" name="submit" class="btn btn-sm btn-info btnm">Simpan</button> 
   <button type="button" class="btn btn-sm btn-warning" style="margin-left:10px" onclick="history.back(-1)" >Kembali </button>
</div>
   </form>

   
</div>
</div>
</div>
<div class="col-sm-12 col-md-7 pnlinstansi1">
<div class="panel panel-info">

   <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h4 class="m-0 font-weight-bold text-primary">Daftar layanan Tersedia</h4>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="data table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                     <th>Setting</th>
                      <th>Nama Dinas</th>
                      <th>Info Layanan</th>
                      <th>Prosedur</th>
                      <th>Syarat</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                 <th>Setting</th>
                     <th>Nama Dinas</th>
                      <th>Info Layanan</th>
                      <th>Prosedur</th>
                      <th>Syarat</th>
                    </tr>
                  </tfoot>
                  <tbody>
                          <?php 
                          $n=1;
                        
                          if($record){
                          foreach($record->result() as $d){
                           $sa=$d->id_layanan;
                            echo '<tr>
                                <td align="center">
                                   
                  <a href="'.base_url().'adminer/editlayanan/'.$d->id_layanan.'" class="btn btn-warning btn-circle btn-sm">
                      Edit
                    <i class="fas fa-exclamation-triangle"></i>
                  </a>
                  <a href="'.base_url().'adminer/dellayanan/'.$d->id_layanan.'"  onclick="perhapuslay('.$sa.')" class="btn btn-danger btn-circle btn-sm">
                    Del
                    <i class="fas fa-trash"></i>
                  </a>
      
                                </td>
                                <td>'.$d->nm_dinas."</td>
                                 <td>".$d->info_layanan."</td>
                                <td>".$d->syarat."</td>
                                 <td>".$d->prosedur."</td>
                              </tr>";
                                 
                              $n+=1;
                          }
                          }

                          ?>

                  </tbody>
                </table>
              </div>
            </div>
          </div>
</div>
</div>