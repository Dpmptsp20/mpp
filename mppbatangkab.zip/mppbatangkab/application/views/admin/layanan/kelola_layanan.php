
<div class="row col-md-12">
	<?php $this->load->view($view1); ?>


</div>