 <div class="paneldetprofil">

                <!-- Single Catagory -->

             <?php 
                if($rec){
             
                  echo '<div class="detprofil">
                         <a href="#">
                            <center>  <img src="'.base_url().'assets/logo/'.$rec[0]['logo'].'" alt="gambar detail instansi" height="50%" class="imgdetprol"> </center>
                         </a> 
                      
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item bc1" style="color:blue"><a href="#">Detail Layanan Instansi</a></li>
                                <li class="breadcrumb-item  active"> '.$rec[0]['info_layanan'].'</li>                         
                            </ol>
                    

                        
                      <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <a  class="navlink12" href="collapseTRI1" data-toggle="collapse" aria-expanded="true" aria-controls="collapseTRI1">
                              <span class="btn btn-info">>> Deskripsi</span>
                            </a>
                        </div>
                       
                         <div id="collapseTRI1" class="collapse" aria-labelledby="headingTRI1" data-parent="#accordionSidebar">
                          <div class="bg-white py-2 collapse-inner rounded">

                              <p class="bgpro" id="bgpro1">  CONTENT : Syarat dan Prosedur <br>'.$rec[0]['profil'].'</p>
                          </div>
                        </div>
                        </div>
                          
                 
                      </div>'
                        ;
                  }
       
          
    
              $c='';
              $i=0;
              $r2='';
           
           
              ?>
                     <center>   <a href="<?=base_url()?>" class="btn btn-sm btn-danger btnlayananh "><i class="fa fa-arrow-circle-left"></i> Kembali ke Menu Utama</a>
                     </center>
            </div>

