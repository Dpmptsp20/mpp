
            <div class="amado-pro-catagory clearfix">

                <!-- Single Catagory -->

             <?php 
                if($rec){
                   $rc= $rec->result_array();

             foreach ( $rc as $key => $v) {
                // <a href="'.$v['website'].'" target="BLANK_">
                echo ' <div class="single-products-catagory clearfix">
                         
                           <a href="'.base_url().'main/detailinstansi/'.$v['id_instansi'].'">
                          <img src="'.base_url().'assets/logo/'.$v['logo'].'" alt="gambar instansi"  class="imgdash">
                            <!-- Hover Content -->
                            <div class="hover-content">
                            <div class="line"></div>
                           
                            <h4 class="fontopd">'.$v['nm_dinas'].'</h4>
                        </div>
                         </a>
                    </div>';
                 }
              }
              
              ?>
            </div>
       
        <!--  Catagories Area End -->