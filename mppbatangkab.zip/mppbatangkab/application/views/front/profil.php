<center>
<video class="vidprofil" controls>
	<?php $ddt=$rec!=null?$rec[0]['video']:'mpp.mp4'; ?>
		<source src="<?php echo base_url();?>assets/vidio/<?=$ddt?>" type="video/mp4">
		<source src="mov_bbb.ogg" type="video/ogg">
	</video>
	<div  class="deskprofil"><p>


<?php $dd=$rec!=null?$rec[0]['latarblg']:'Tidak Ada descripsi profil yang tersedia'; 
		echo $dd.'  '.$ddt;
?>
	</p>
</div>
</center>