 <div class="paneldetprofil">

                <!-- Single Catagory -->

             <?php 
                if($rec){
             
                  echo ' <div class="detprofil">
                         <a href="'.$rec[0]['website'].'" target="BLANK_">
                            <center>  <img src="'.base_url().'assets/logo/'.$rec[0]['logo'].'" alt="gambar detail instansi"  class="imgdetpro"> </center>
                         </a> 
                      
                            <ol class="breadcrumb bread2">
                                <li class="breadcrumb-item bc1" style="color:blue"><a href="#">Detail Instansi</a></li>
                                <li class="breadcrumb-item  active"> '.$rec[0]['nm_dinas'].'</li>                         
                            </ol>
                    
                           <div class="bginduk">
                        
                          <div class="bg-white py-2 collapse-inner rounded">
                              
                              <div class="bgpro"><span style="font-size:16pt;text-align:center;color:black">Profil Singkat</span></br>'.$rec[0]['profil'].'</div>
                          </div>
                   
                      <div class="input-group mb-3">
                        <div class="input-group-prepend">
                           
                        <div>
                        
             <select  name="kategori" class="form-control" id="syarat">
             <option>--+      Informasi Lengkap Layanan     +--</option>' ;
                  }
              $c=count($rec);
         for($i=0;$i<$c;$i++){
              echo "<option value='".$rec[$i]['id_layanan']."'>".$rec[$i]['info_layanan']."</option>";
            }

            if($rec){
              echo'   
              </select>
     </div>
</div>
            </div>
                       <div id="collapseTRI" class="collapse cols-md-12" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                          <div class="bg-white py-2 collapse-inner rounded">
<div class="scrolside">
                              <p class="bgpro" id="bgpro1"> </p>
              </div>
                          </div>
                        </div>
                            <center>   <span class="btn btn-warning btnlayanan">Informasi Layanan</span></center>
                                                 
                        </div>
                      </div>';
              }
              $r='<div class="row infolayanan"> ';
              $c='';
              $i=0;
              $r2='';
              foreach ($rec as $key => $v) {
                if($v['info_layanan']!=''){$i+=1;}
              
                $c.='<div class="col-md-4 col-sm-12>'.$v['info_layanan'].'</div>';
                $r2.='<span class="fa fa-location-arrow infolayanan-item"> 
                        <a href="'.base_url().'main/detaillayanan/'.$v['id_layanan'].'" target="BLANK_">
                          '.$v['info_layanan'].'
                         </a> </span>';
              
               if(($i%3)==0){
                $c.='</div>';
                $r.=$c;
            //  echo $r;
              $c='';
             // $i=0;
               }
              }
               if($i>0){ echo $r2;}else{
                  echo '
                      <center>
                      <div class="card cardnotif">
                        <div class="card-body">
                          BELUM ADA LAYANANA YANG BISA DITAMPILKAN.....
                        </div>
                      </div>
                      </center>';
                } 
             
              ?>
                     <center>   <a href="<?=base_url()?>" class="btn btn-sm btn-danger btnlayananh "><i class="fa fa-arrow-circle-left"></i> Kembali ke Menu Utama</a></center>
            </div>

