<center>
	<div class="panelberita">
  <img  class="d-block detfotoberita "  src="<?=base_url()?>assets/fotoberita/<?=$rec[0]['gambar']?>" height="50%"   alt="Berita Tanpa logo">
        
	<div  class="deskprofil"><p>


<?php $dd=$rec!=null?$rec[0]['isi_berita']:'Tidak Ada descripsi profil yang tersedia'; 
		echo $dd.'  ';
?>
	</p>
</div>

                    <a href="<?=base_url()?>main/berita" class="btn btn-sm btn-danger btnlayananh "><i class="fa fa-arrow-circle-left"></i> Kembali ke <i>Menu Berita</i></a>
</div>
</center>