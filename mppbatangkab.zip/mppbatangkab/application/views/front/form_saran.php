
<center>
<div class="col-sm-12 col-md-12 pninputsaran">
<div class="panel panel-info">
<div class="panel-heading "><span class="fsaran">Form Input Saran / Aduan</span>
   <form class="animated bounceInDown mw-100 caduan">
            <div class="input-group">
              <input name="cari" id="ids"  type="text" class="longinput  form-control bg-light sran" placeholder="Telusuri status saran & aduan..." aria-label="Search" aria-describedby="basic-addon2">
              <input name="cari" id="baseurla" value="<?=base_url()?>main/carires"  type="hidden" class="form-control bg-light">
              <!--  <input name="cari1"  type="text"  class="longinput  form-control bg-light sran1" placeholder="Telusuri status saran..." aria-label="Search" aria-describedby="basic-addon2">-->
              <div class="input-group-append">
                <a href="#"  onclick="theFunction()" class="btn btn-primary">  <i class="fa fa-search fa-sm"></i></a>
               <!-- <button class="btn btn-primary" type="button">-->
               </div>
            </div>
  </form>
          </div>
          <div id="inta"></div>
         <br>
<div class="panel-body" style="margin-top: 3%">
<?php echo  $this->session->flashdata('alertpostsaran');?>
<form action="<?php echo base_url();?>main/saranaduan" method="post" role="form"  enctype='multipart/form-data'> 
     <div class="form-group"> 
      <label for="kd" class="col-sm-3">Nama Lengkap :</label> 
     <div  class="col-md-9">
<input type="hidden" name="baseurl" id="baseurl" value="<?php echo base_url()?>main/getpelayanan">
      <input type="text" name="nmk"  class="form-control" placeholder="Input Nama Lenkap Anda" required="required"> 
    </div>
   </div> 
       <div class="form-group"> 
      <label for="kd" class="col-sm-3">Email :</label> 
       <div class="col-md-9"> 
      <input type="text" class="form-control" name="email"  placeholder="Input Email Anda"> 
    </div>
   </div> 
   <div class="form-group" > 
       <label for="jnspesan"  class="col-sm-3">Jenis Pesan :</label> 
        <div class="col-md-9">
        <select name="jnspesan"  class="w-100" required>
            <option value='----'> ----</option>
           <option value='Saran'>Saran</option>
           <option value='Aduan'>Aduan</option>
           <option value='pertanyaan'>Pertanyaan</option>
      </select>
</div>
 </div>

    <div class="form-group">
       <label for="instansi"  class="col-sm-3">Instansi yang dituju :</label> 
          <div class="col-md-9">
         <select  name="instansi" id="instansi" class="w-100"> 
     <option value='----'> ----</option>
         <?php     $c=count($rec);
         for($i=0;$i<$c;$i++){
          //  if ($rec[$i]['id_layanan']){
             echo "<option value='".$rec[$i]['id_instansi']."' >".$rec[$i]['nm_dinas']."</option>";
           // }
           
          }
              ?>
      </select>
       </div>
   </div>
    <div class="form-group"> 
       <span  id="layanan" >
     
       </span>
   </div> 

   <div class="col-md-12 form-group">
       <label for="file" class="col-sm-3">Informasi Pesan :</label> 
          <textarea name='pesan' rows=10   class="col-md-9 form-control" ></textarea>
   </div>
   
<div class="form-group"> 
   <button type="submit" name="submit" class="btn btn-sm btn-info btnm">Simpan</button> 
   <button type="button" class="btn btn-sm btn-warning" style="margin-left:10px" onclick="history.back(-1)" >Kembali </button>
</div>
   </form>
</div>
</div>
</div>
<div class="col-sm-12 col-md-7 pnlinstansi1">
<div class="panel panel-info">

 
</div>
</div>
</center>

<!--Modal HTML -->
<div id="myModal"  class="modal fade">
    <div class="modal-dialog" style="background-color: white;width: 100%">


 <section class="breadcrumbs-v1">
    <div class="container">
         <button type="button" class=" btn-sm btn-danger" style="position:relative;margin-left: 93%" data-dismiss="modal">
                <i class="fa fa-close"> Keluar</i></button>
    </div>
</section>
<section class="content">
    <div class="container">
        <div class='box-body' >
         <h4><a>Input Response</a><h4>
             
            <center>
          
            <br>
       <textarea name="response"></textarea> 
        </center>  
        </div>          
    </div>
</section>

</div>

</div>