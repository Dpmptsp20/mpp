
<center>
<div class="col-sm-12 col-md-12 pdownload">
<div class="panel panel-info">
<div class="panel-heading ">
	
               <h3 class="judulberita"> 
                  <ol class="breadcrumb">
                             <li class="breadcrumb-item"><span class="fsaran">Download   </span>	</li> <li class="breadcrumb-item"><a href="#">Daftar Download File</a></li>
                    </ol>
               </h3>
	<table width="100%" class="table table-striped table-bordered data">
			<thead>
				<tr>			
					<th width="5%">No</th>
					<th>Tentang</th>
					<th  width="10%">extensi</th>
					<th  width="20%">Nama File</th>
					<th  width="15%">Download</th>
				</tr>
			</thead>
			<tbody>
			<?php 
			$no=1;
			foreach ($rec as $k) {
				$ij=explode('.',$k->nama_file);
				echo '
					<tr>				
					<td>'.$no.'</td>
					<td>'.$k->judul.'</td>
					<td>'.$ij[1].'</td>
					<td>'.$ij[0].'</td>
					<td><a href="'.base_url().'main/donlot/'.$k->nama_file.'" class="btn btn-sm btn-info bd"><i class="fa fa-download fa-download-lg"> '.$k->hits.'X </i></a></td>
				</tr>
				'; 
				$no+=1;
			}
			
			?>
			</tbody>
		</table>
</div>
</div>
</div>
