 <center>
  <div id="bgberita">	
				<div class="breadberita">
	 					   <ol class="breadcrumb">
                                <li class="breadcrumb-item bc1" style="color:black"><a href="#">Berita</a></li>
                                <li class="breadcrumb-item  active">Daftar Berita</li>                         
                            </ol>
				</div>
                        
<div id="kontrolberitampp" class="carousel slide " data-ride="carousel">
      <div class="carousel-inner ">
     

  <?php 
          $ind=0;
           $i=1;
       //   foreach ( $csl as $k => $v) {
           for($ix=0;$ix<$jmlp;$ix++) {
            if($ind==0){
                echo' <div class="carousel-item active">';
              }else{
                 echo' <div class="carousel-item ">';
              }
             if($csl[$ix]['gambar']==''){
                    echo '
                    	<div class = "panel panel-default">
						   <div class = "panel-body bgberita">
						   <img  class="d-block panelberita"  src="'.base_url().'assets/img/core-img/log1.jpg"  alt="Berita Tanpa gambar">'.$ix;
                echo '</div>
            </div>
                  ';
                      }else{
                      echo '<div class=" panelberita">';
                       for($i=1;$i<$jmlb;$i++){ 
                        $ind++;
                      //  $i++;
                        if($ind<$jmlb){
                            echo '
                          <a href="'. base_url().'main/detailberita/'.$csl[$ind]['id_berita'].'">
                          <img  class="col-md-3  gbrberita" src="'.base_url().'assets/fotoberita/'.$csl[$ind]['gambar'].'"  alt="Berita Tanpa gambar">
                          </a>
                          ';
                        }
                        
                          if(($ind%9)==0){break;}
                        }
                       echo '</div>';
                }
		 echo  '</div>';
              $ind++;
          }

          ?>
     </div> 

  
      <a class="carousel-control-prev" href="#kontrolberitampp" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#kontrolberitampp" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
</div>

</div>
</center>