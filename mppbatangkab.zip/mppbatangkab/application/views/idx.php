<div class="dashindex">
<img class="gambardash" src="<?=base_url()?>assets/log21.jpg"/>

</div>