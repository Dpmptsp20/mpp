
	<style type="text/css">
		body{
			font-family: roboto;
		}
	</style>

   
 <section>
	<h2  class="graf">Kuesioner SKM<small style="float:right;margin-right: 20px">Double click untuk memilih</small></h2>
	<div class="skmtengah">
 <?php 
 $ips= $_SERVER['REMOTE_ADDR'];
 echo"<input type='hidden' id='ipadd' value='".$ips."'> ";
 	for($i=1;$i<5;$i++){
		echo "<!--<a onclick='upskm(".$i.")'' href='".base_url()."main/saveskm/".$i."'><img class='gambar' src='".base_url()."assets/".$i.".png'/></a>-->
		<a class='btn' ondblclick='upskm(".$i.")'><img class='gambar' src='".base_url()."assets/".$i.".png'/></a>";
 } 

 	?>

</div>

 	<?php
 if($datagr){
  echo'

<div class="col-md-12" style="float: right;">
	<h2  class="graf">Grafik Surver Kepuasan Masyarakat</h2>
	<div class="col-md-6">
		<canvas id="myChart"></canvas>
	</div>
	 <div  class="col-md-6 grfr" >
		<canvas id="myChartb"></canvas>
	</div>
</div>';
}else{
	echo 'tanpa data';
}

?>
<div id="outpu">

</div>

</section>
