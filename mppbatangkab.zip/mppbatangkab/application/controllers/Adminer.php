<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Adminer extends CI_Controller {
	public function __construct(){
		parent:: __construct();
 //check_admin();
		$this->load->model("model_instansi");
		$this->load->model("model_interf");
			
		$this->load->model("model_berita");
		    /*	$this->load->model("model_user");
		*/
	}

  public function index()
  {

    $data['view']='idx';
      $this->load->view('admindash',$data);
  }
  public function login()
  {

    //$data['view']='idx';
      $this->load->view('admin/login');
  }
   function kelola_download(){

      $this->load->library('pagination');
     $config['base_url']=base_url().'adminer/kelola_download';
     $config['total_rows']=$this->model_interf->view_download()->num_rows();
     $config['per_page']=10;
     $this->pagination->initialize($config);
    $data['paging']=$this->pagination->create_links();
    $h=$this->uri->segment(3);
    $h=$h==''?0:$h;
      $data['posisi']=$h;
    $f=$this->model_interf->viewpagingdownload($h);
    if($f!=false){
      $data['record']=$f;
      $data['view1']='admin/download/input_download';
      $data['view']='admin/download/kelola_download';
        $this->load->view('admindash',$data);
    }else{
      $this->session->set_flashdata('pesanfieldnull','<tr><td colspan="4"><marquee scrolldelay="0.5">List File Download Kosong. . . </marquee></td></tr>');
         $data['record']=$f;
          
        $data['view']='admin/download/kelola_download';
        $data['view1']='admin/download/input_download';
       $this->load->view('admindash',$data);
    } 
  }
    function editdownload(){
  
      $ind=$this->uri->segment(3);
   $r=$this->model_interf->eddownload($ind)->result_array();
   $data['record1']=$r;
    $f=$this->model_interf->view_download();
    if($f!=false){
      $data['record']=$f;
     
    }else{
      $this->session->set_flashdata('pesanfieldnull','<tr><td colspan="4"><marquee scrolldelay="0.5">List File Download Kosong. . . </marquee></td></tr>');
       $data['record']=false;

    } 

  $data['view']='admin/download/kelola_download';
  $data['view1']='admin/download/edit_download';
  $this->load->view('admindash',$data);
}
 function posdownload(){
if(isset($_POST['submit'])){
      $lokasi_file = $_FILES['fupload']['tmp_name'];
      $nama_f  = $_FILES['fupload']['name'];
      $tgl_sekarang = date("Ymd");
     $nama_file= str_replace(' ', '-', $nama_f);
    
  // Apabila ada gambar yang diupload
//var_dump($_FILES);die; 
   // var_dump($lokasi_file);die; 
  if (!empty($lokasi_file)){
  //var_dump($lokasi_file);die; 
    
   $config['upload_path']          = './assets/files/';
    $config['allowed_types']        = "gif|jpg|jpeg|png|iso|dmg|zip|rar|doc|docx|xls|xlsx|ppt|pptx|csv|ods|odt|odp|pdf|rtf|sxc|sxi|txt|exe|avi|mpeg|mp3|mp4|3gp";
  //  $config['max_size']             = 0;
  //  $config['max_width']            = 5024;
  //  $config['max_height']           = 4068;
    $config['file_name']             = $nama_file;
    $this->load->library('upload', $config);
            if ( ! $this->upload->do_upload('fupload')){
                   $error = array('error' => $this->upload->display_errors());
                    $this->session->set_flashdata('pesankeloladownload','<div class="alert alert-warning"><marquee> <strong>'. $error['error'].'</  strong></marquee></div>');
                      redirect("adminer/kelola_download");
          }else{
            $this->datado=array(
                        'judul'=>$_POST['judul'],
                        'nama_file'=>$nama_file,
                        'tgl_posting'=>$tgl_sekarang
                        );
          }
  
      }else{
               $this->datado=array(
                        'judul'=>$_POST['judul'],
                        'tgl_posting'=>$tgl_sekarang
                        );
  }

 // var_dump($this->datado);die;
  $rd=$this->model_interf->postdownload($this->datado);
  if($rd!=0){

                    $this->session->set_flashdata('pesankeloladownload','<div class="alert alert-info"><marquee> <strong>Upload file berhasil. . . </  strong></marquee></div>');
  }else{
                       $this->session->set_flashdata('pesankeloladownload','<div class="alert alert-warning"><marquee> <strong>Upload File Gagal. . . </  strong></marquee></div>');
 
  }

  redirect("adminer/kelola_download");
  }
  }
		public function dashboard()
	{
		$data['record']=$this->model_instansi->view_instansi();
		$data['view']='admin/instansi/input_instansi';
			$this->load->view('admindash',$data);
	}
	//PROFIL
	public function profil()
	{
		$data['rec']=$this->model_interf->view_profil()->result_array();
		$data['view']='admin/profil/kelola_profil';
			$this->load->view('admindash',$data);
	}
# berita
    public function berita(){
    
 $f=$this->model_berita->view_ber();
    if($f!=false){
        $this->session->set_flashdata('pesankelolaberita','<div style="width:100%"><marquee scrolldelay="0.5">Kelola List Data Berita. . . </marquee></div>');
      $data['record']=$f;
      $data['view']='admin/berita/kelola_berita';
      $this->load->view('admindash',$data);
    }else{
      $this->session->set_flashdata('pesankelolaberita','<div><marquee scrolldelay="0.5">List Data Berita  Kosong. . . </marquee></div>');
         $data['record']=$f;
          $data['viewin']='admin/berita/input_berita';
        $data['view']='admin/berita/kelola_berita';
     $this->load->view('admindash',$data);
    }
  }
  #saran dan aduan
   public function saranaduan(){
    
 $f=$this->model_interf->view_saranaduan();
    if($f!=false){
        $this->session->set_flashdata('pesankelolasaran','<div style="width:100%"><marquee scrolldelay="0.5">Kelola List Data Saran & Aduan. . . </marquee></div>');
      $data['record']=$f;
     
        $data['view']='admin/saran/saranadu';
      $this->load->view('admindash',$data);
    }else{
      $this->session->set_flashdata('pesankelolasaran','<div><marquee scrolldelay="0.5">List Data Saran & Aduan  Kosong. . . </marquee></div>');
         $data['record']=$f;
          $data['viewin']=' ';
        $data['view']='admin/saran/saranadu';
     $this->load->view('admindash',$data);
    }
  }

#Pengelola layanan 
    public function kelola_layanan(){
    
 $f=$this->model_instansi->view_layananins();
//var_dump($f->result());die;
    if($f!=false){
        $this->session->set_flashdata('pesankelolalayanan','<div style="width:100%"><marquee scrolldelay="0.5">Kelola List Data Layanan Instansi. . . </marquee></div>');
      $data['record']=$f;
         
         $dt=$this->model_instansi->view_instansiall()->result_array();
         $data['rkat']= $dt;
     //    var_dump($dt->result_array());die;
       $data['view1']='admin/layanan/input_layanan';
        $data['view']='admin/layanan/kelola_layanan';
      $this->load->view('admindash',$data);
    }else{
      $this->session->set_flashdata('pesankelolasaran','<div><marquee scrolldelay="0.5">List Data Saran & Aduan  Kosong. . . </marquee></div>');
         $data['record']=$f;
          $data['viewin']=' ';
  $data['rkat']='admin/layanan/input_layanan';
        $data['view']='admin/layanan/kelola_layanan';
        $data['view1']='admin/layanan/input_layanan';
     $this->load->view('admindash',$data);
    }
  }
  #kelola layanan
  public function postlayanan()
  {
          if(isset($_POST['submit'])){
            
               
                           $ins=$_POST['ins'];
                            $nm=$_POST['nm'];
                            $b=$_POST['biaya'];
                            $w=$_POST['waktu'];
                            $d=$_POST['dasar_hukum'];
                              $pr=$_POST['prosedur'];
                            $ly=$_POST['syarat'];
                            $p=$_POST['penjelasan'];
                  $dat=array(         'id_instansi'=>$ins,
                                      'info_layanan'=>$nm ,
                                      'prosedur'=>$pr,
                                      'syarat'=>$ly,
                                      'biaya'=>$b,
                                      'dasar_hukum'=>$d,
                                      'jangka_waktu'=>$w,
                                      'penjelasan'=>$p

                               );
                //  var_dump($dat);die;
               $r=$this->model_instansi->poslayanan($dat);
                
                $s='';
                  if($r==true){$s.='dan tersimpan';
                  $this->session->set_flashdata('alertpostinstansi','<div class="alert alert-warning"><marquee> <strong> Data Layanan Instansi Berhasil di Post '.$s.'</strong></marquee></div>');
                }else{
                   $this->session->set_flashdata('alertpostinstansi','<div class="alert alert-warning"><marquee> <strong>Post Data Layanan Instansi Gagal </strong></marquee></div>');
                }
                  redirect('adminer/kelola_layanan');
           }//end submit
      $data['view']='admin/layanan/input_layanan';
      $this->load->view('admindash',$data);
  }//end function
#kelola instansi
	public function postinstansi()
	{
if(isset($_POST['submit'])){
	//echo 'masuk ';die;
    if($_FILES['fupload']['name']!==''){
        $lokasi_file    = $_FILES['fupload']['tmp_name'];
        $tipe_file      = $_FILES['fupload']['type'];
        $nama_file      = $_FILES['fupload']['name'];
        $acak           = rand(1,99);

        if(( $tipe_file == 'image/jpg')or($tipe_file == 'image/jpeg')){
            $nama_file_unik = 'ok'.$acak.$nama_file; 
          }else{
           $nama_file_unik = $acak.$nama_file; 
        }
    
					 $seminggu = array("Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu");
					$hari = date("w");
					$hari_ini = $seminggu[$hari];
					 $tgl_sekarang = date("Ymd");
					$tgl_skrg     = date("d");
					$bln_sekarang = date("m");
					$thn_sekarang = date("Y");
					$jam_sekarang = date("H:i:s");
	

		$lokasi_file    = $_FILES['fupload']['tmp_name'];
        $tipe_file      = $_FILES['fupload']['type'];
        $nama_file      = $_FILES['fupload']['name'];
        $acak           = rand(1,99);
        if(( $tipe_file == 'image/jpg')or($tipe_file == 'image/jpeg')){
            $nama_file_unik = 'ok'.$acak.$nama_file; 
          }else{

           $nama_file_unik = $acak.$nama_file; 
        }

//	var_dump($nama_file_unik);die;
	    $config['upload_path']          = './assets/logo/';
	    //$config['upload_path']          = './gambar/';
	    $config['allowed_types']        = 'gif|jpg|png|jpeg';
	    $config['max_size']             = 0;
	    $config['max_width']            = 5024;
	    $config['max_height']           = 4068;
	    $config['file_name']             = $nama_file_unik;
	    $this->load->library('upload', $config);
 
	    if ( ! $this->upload->do_upload('fupload')){
	           $error = array('error' => $this->upload->display_errors());
	            $this->session->set_flashdata('alertpostinstansi','<div class="alert alert-warning"><marquee> <strong>'. $error['error'].'</  strong></marquee></div>');
	            redirect('adminer/dashboard');
	    }else{
	      $data = array('upload_data' => $this->upload->data());

	              	$kdin=$_POST['kd'];
	              	$nmin=$_POST['nm'];
	              	$pro=$_POST['profil'];
	              	$wb=$_POST['link'];
				$dat=array('kd_dinas'=>$kdin,
				            		'nm_dinas'=>$nmin ,
				                    'profil'=>$pro ,
				                    'website'=>$wb ,
				                    'logo'=> $nama_file_unik
				                );
		 $r=$this->model_instansi->postint($dat);
			
			$s='';
	      if($r==true){$s.='dan tersimpan';
	  	  $this->session->set_flashdata('alertpostinstansi','<div class="alert alert-warning"><marquee> <strong> Data Instansi Berhasil di Post '.$s.'</strong></marquee></div>');
			}else{
				 $this->session->set_flashdata('alertpostinstansi','<div class="alert alert-warning"><marquee> <strong>Post Data Instansi Gagal </strong></marquee></div>');
			}

		 }


	      redirect('adminer/dashboard');
    	}  //upload file end
 
	}//end submit
			$data['view']='admin/instansi/input_instansi';
			$this->load->view('admindash',$data);
	}//end function
 function hapus_saran(){
    $u=$this->uri->segment(3);
    $u4=$this->uri->segment(4);
//   var_dump($u4);die;
    $da=$this->model_interf->delsaran($u);
    if($da){
    $this->model_interf->delrespon($u4);

    ?>
                        <script type="text/javascript">
        alert('Data Saran & Aduan berhasil dihapus....');
        //window.history.go(-2);
        window.location.href="<?php echo base_url()?>adminer/saranaduan";
      </script> 
      <?php
    }else{
      ?>
             <script type="text/javascript">
        alert('Data Saran & Aduan berhasil dihapus....');
        //window.history.go(-2);
        window.location.href="<?php echo base_url()?>adminer/saranaduan";
      </script>
     <?php
    }
   redirect('adminer/saranaduan');
  }
  function delinstansi(){
    $u=$this->uri->segment(3);
      $q = $this->model_instansi->getinstansi($u)->row_array();
//var_dump($q);die;
       if($q){

       unlink("./assets/logo/".$q['logo']);
  
    $da=$this->model_instansi->deleteint();
    ?>
                        <script type="text/javascript">
        alert('Data Instansi berhasil dihapus....');
        //window.history.go(-2);
        window.location.href="<?php echo base_url()?>adminer/dashboard";
      </script>
      <?php
 die; }   

  //  redirect('adminer/daftar_kategorimap');
  }
  public function adddownload(){

  $data['view']='admin/download/input_download';
  $this->load->view('admindash',$data);
      //$this->load->view('dashboardnew',$data);
  }

   public function editinstansi() {
   	$uin=$this->uri->segment(3);
     	if(isset($_POST['submit'])){
     	$kd=$this->input->post('kd');
     	$nm=$this->input->post('nm');
     	$pr=$this->input->post('profil');
 		$lk=$this->input->post('link');
//echo $kd.' '.$nm.' '.$pr.' '.$lk;die;
		  $lokasi_file    = $_FILES['fuploadup']['tmp_name'];
		  $tipe_file      = $_FILES['fuploadup']['type'];
		  $nama_file      = $_FILES['fuploadup']['name'];
		  $acak           = rand(1,99);
          $nama_file_unik = $acak.$nama_file; 
    
	    $config['upload_path']          ='./assets/logo/';
	    $config['allowed_types']        = 'gif|jpg|png|jpeg';
	    $config['max_size']             = 0;
	    $config['max_width']            = 5024;
	    $config['max_height']           = 4068;
	    $config['file_name']             = $nama_file_unik;
	    $this->load->library('upload', $config);
		 		if(!empty($lokasi_file)){	
				    if ( ! $this->upload->do_upload('fuploadup')){
				      $error = array('error' => $this->upload->display_errors());
				     }else{
				      $data = array('upload_data' => $this->upload->data());
				          $dat=array(
				            'kd_dinas'=>$kd,
				            'nm_dinas'=>$nm,
				            'profil'=>$pr,
				            'website'=>$lk,
				           'logo'=>$nama_file_unik
				         );
				           $delun= $_POST['logo'];
				   }//tutup jika terupload
		 		}else{   //cek lokasi file #jika foto instansi kosong
			     $dat=array(
			            'kd_dinas'=>$kd,
			            'nm_dinas'=>$nm,
			            'profil'=>$pr,
			            'website'=>$lk
			         );
			     $delun='';
				 }#end jika foto instansi kosong
		 	$id=$_POST['id'];
	//var_dump($dat);die;
	$ur=$this->model_instansi->updateinstansi($id,$dat);
//var_dump($ur);die;
		 		$s='';
	   if($ur){$s.='dan tersimpan';
	  	  $this->session->set_flashdata('alertpostinstansi','<div class="alert alert-warning"><marquee> <strong> Data Instansi Berhasil diupdate '.$s.'</strong></marquee></div>');
	  	  	 if($delun!=''){
			   		 unlink("./assets/logo/$delun");
		    		}
			}else{
				 $this->session->set_flashdata('alertinputinstansi','<div class="alert alert-warning"><marquee> <strong>Update Data Instansi Gagal </strong></marquee></div>');
				$data['rec1']=$this->model_instansi->getinstansi($uin)->result_array();
				$data['view']='admin/instansi/edit_instansi';
				
			}	
			$data['record']=$this->model_instansi->view_instansi();
        $data['view']='admin/instansi/input_instansi';
				$this->load->view('admindash',$data);	
   }else{
   	//echo "tanpa submit";die;
		$data['record']=$this->model_instansi->view_instansi();
 	  	$data['rec1']=$this->model_instansi->getinstansi($uin)->result_array();
		$data['view']='admin/instansi/edit_instansi';
		$this->load->view('admindash',$data);
   }
}
#kelola profil /vidio
 function edtprofil() {
     	if(isset($_POST['submit'])){
		$q=$_POST['vid'];
       			$q1=explode('.',$q);
  //	unlink("./vidio/mpp.png");die;

      if (isset($_FILES['video']['name']) && $_FILES['video']['name'] != '') {
        unset($config);
       $acak           = rand(1,99);
        $configVideo['upload_path'] = './assets/vidio/';
       // $configVideo['max_size'] = '60000';
        $configVideo['max_size']  = 0;
        $configVideo['allowed_types'] = 'avi|flv|wmv|mp4|jpg|png';
     //   $configVideo['overwrite'] = FALSE;
        //$configVideo['remove_spaces'] = TRUE;
        $video_name =  $acak .$_FILES['video']['name'];
        $configVideo['file_name'] = $video_name;

        $this->load->library('upload', $configVideo);
        $this->upload->initialize($configVideo);
        if(!$this->upload->do_upload('video')) {
        	echo 'terjadi error saat upload';
            echo $this->upload->display_errors();
        }else{
       	
        	unlink("./assets/vidio/".$q);
            $videoDetails = $this->upload->data();
            $data['video_name']= $configVideo['file_name'];
            $data['video_detail'] = $videoDetails;
          

           redirect('adminer/edtprofil');
        }

    }else{
        echo "Please select a file";die;
    }
        //}else{
        	 
        	
   	 }else{
   	 		$ui=$this->uri->segment(3);
        	//	$dr= $this->model_instansi->getinstansi($ui)->row_array();
        			$dr=$this->model_interf->view_profil()->result_array();
        		//var_dump($dr);die;
        			$data['rec']=$dr;
        		$data['view']='admin/instansi/upvidio';
     //   }
       
			$this->load->view('admindash',$data);
       

   	 }
    }

#KELOLA BERITA
    function editberita(){
    		  $lokasi_file    = $_FILES['fuploadup']['tmp_name'];
		  $tipe_file      = $_FILES['fuploadup']['type'];
		  $nama_file      = $_FILES['fuploadup']['name'];
		  $acak           = rand(1,99);
          $nama_file_unik = $acak.$nama_file; 
    
	     $config['upload_path']          = './assets/gambar_berita/';
	     $config['allowed_types']        = 'gif|jpg|png|jpeg';
	    $config['max_size']             = 0;
	    $config['max_width']            = 5024;
	    $config['max_height']           = 4068;
	    $config['file_name']             = $nama_file_unik;
	    $this->load->library('upload', $config);
 		 if(!empty($lokasi_file)){

    if ( ! $this->upload->do_upload('fuploadup')){
      $error = array('error' => $this->upload->display_errors());
     }else{
      $data = array('upload_data' => $this->upload->data());
     // $r=$this->model_berita->post($databerita);
      $ns='small_'.$nama_file_unik;
      $config2['image_library'] = 'gd2';
      $config2['source_image'] = './assets/foto_berita/'.$nama_file_unik;
      $config2['new_image'] = './assets/foto_berita/'.$ns;
      //$config2['create_thumb'] = TRUE;
      $config2['maintain_ratio'] = TRUE;
      $config2['width'] = 80;
      $config2['height'] = 50;
      $this->load->library('image_lib', $config2);
      $this->image_lib->resize();
      // handle if there is any problem
      if ( ! $this->image_lib->resize()){
             echo $this->image_lib->display_errors();die;
        }
          $dat=array(
            'judul'=>$_POST['judulup'],
            'id_kategori'=>$_POST['kategori'],
            'headline'=>$_POST['headline'],
            'tag'=>$tag,
            'isi_berita'=>$_POST['isi_berita'],
            'status'=>$_POST['status'],
           'gambar'=>$nama_file_unik

         );
           $delun= $_POST['namagambar'];

        
   }//tutup jika terupload
 }else{   //cek lokasi file

     $dat=array(
            'judul'=>$_POST['judulup'],
            'id_kategori'=>$_POST['kategori'],
            'headline'=>$_POST['headline'],
            'tag'=>$tag,
            'isi_berita'=>$_POST['isi_berita'],
            'status'=>$_POST['status'],

         );
     $delun='';
 }


  $id=$_POST['id'];
   $ur=$this->model_berita->updateberita($id,$dat);
   if($ur){

   // if(isset($_POST['namagambar'])){
    if($delun!=''){
     
     
     $dels='small_'.$delun;
  //
    unlink("./assets/foto_berita/$delun");
    unlink("./assets/foto_berita/$dels");
   // echo $delun.' '.$dels;die;
    }
  redirect('adminer/kelola_berita');
	 }else{
   	 		
   	 		$re=$this->model_instansi->getinstansi($uin);
   	 		if($re){
   	 			$data['rec1']=$re->result_array();
   	 		}else{
   	 			$data['rec1']=null;
   	 		}
   	 		
   		 	$data['record']=$this->model_instansi->view_instansi();
   		 	$data['view']='admin/instansi/edit_instansi';
     		$this->load->view('admindash',$data);
   	 }
    }



function tanggapan(){
 $t= $this->input->post('tanggapan');
  $i= $this->input->post('id');
  $res = array('respon' => $t,
                'id_saranadu'=>$i );
  $re=$this->model_interf->posres($res);
  if($re){
  ?>
                        <script type="text/javascript">
        alert('Data respon "<?php echo $i;?> berhasil dipost....');
        //window.history.go(-2);
        window.location.href="<?php echo base_url()?>adminer/saranaduan";
      </script>
      <?php
    }else{
        ?>
                        <script type="text/javascript">
        alert('Data respon gagal dipost....');
        //window.history.go(-2);
        window.location.href="<?php echo base_url()?>adminer/saranaduan";
      </script>
      <?php
    }
 die; 
}

 
    public function skm()
  {
    $data['rec']=$this->model_instansi->view_instansigov();
    $data['view']='admin/skm/grafik';
    $data['datagr']='1';
      $this->load->view('admindash',$data);
  }
    public function resetskm()
  {
    $re=$this->model_interf->resetskm();
  if($re){
  ?>
                        <script type="text/javascript">
        alert('Reset Data SKM berhasil...');
        //window.history.go(-2);
        window.location.href="<?php echo base_url()?>adminer/skm";
      </script>
      <?php
    }else{
        ?>
                        <script type="text/javascript">
        alert('Reset SKM Gagal....');
        window.location.href="<?php echo base_url()?>adminer/skm";
      </script>
      <?php
      die;
    }
  }
}
