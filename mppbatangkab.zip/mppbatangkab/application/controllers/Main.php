<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent:: __construct();
		$this->load->model("model_instansi");
			$this->load->model("model_interf");
			$this->load->model("model_berita");
		/*	$this->load->model("model_user");
		*/
	}

	public function index()
	{
		$data['rec']=$this->model_instansi->view_instansi();
		$data['view']='front/home';
			$this->load->view('dash',$data);
	}
	function carires(){
    $u=$this->input->post('id');
    //echo $u;die;
    if($u!=''){
       $da=$this->model_interf->getres($u);
     //  var_dump($da);die;
       if($da){
        $data1='Direspon tanggal : '.$da[0]['tanggal'].'<br>Jawaban :';
        $data1.=$da[0]['respon'];
           echo $data1;
       }else{
            echo 'data tidak tersedia';
       }
     }else{
      echo 'Tolong lengkapi inputan anda   !';
     }
   

  //  redirect('adminer/daftar_kategorimap');
  }
  	public function getinstansi()
	{
		 $u=$this->input->post('id');
		$da=$this->model_instansi->view_layananinssy($u)->result_array();
		 if($da){
		$l= 	$da[0]['link'];
		 	  $data1='Penjelasan : <p>'.$da[0]['penjelasan'].'</p>';
        $data1.='</br>Persyaratan : <p>'.$da[0]['syarat'].'</p><br>Prosedur :<p>';
        $data1.=$da[0]['prosedur'].'</p><br>Dasar Hukum :<p>';
        $data1.=$da[0]['dasar_hukum'].'</p><br>Tarif Biaya :<p>';
        $data1.=$da[0]['biaya'].'</p><br>Jangka Waktu :<p>';
        $data1.=$da[0]['jangka_waktu'].'</p>Link Layanan Online Tersedia :';
        if($l!=''){
        	 $data1.='&nbsp;<a href="'.$da[0]['link'].'" target="blank" style="color:blue;font-size:14pt;font-style:italic;">'.$da[0]['link'].'</a></p>';
        	}else{
        		 $data1.=' - </p>';
        	}
       
           echo $data1;
       }
	
	}
	public function gov()
	{
		$data['rec']=$this->model_instansi->view_instansigov();
		$data['view']='front/home';
			$this->load->view('dash',$data);
	}
	public function skm()
	{
		$data['rec']=$this->model_instansi->view_instansigov();
		$data['view']='grafik';
		$data['datagr']='1';
			$this->load->view('dash',$data);
	}
	function saveskm(){
		$k=$this->uri->segment(3);
      //  $k=$this->input->post('kds');
        $data=$this->model_interf->saveskm($k);
     //   redirect('main/skm');
        echo json_encode($data);
    }
 function simpanskm(){
 //	echo $ip = $_SERVER['REMOTE_ADDR'];die;
        $k=$this->input->post('kds');
        $i=$this->input->post('ip');
       $r=$this->model_interf->getskm($i);
        if($r){
        	$data=false;
 echo json_encode($data);
        }else{
        	$data=$this->model_interf->saveskma($k,$i);
        echo json_encode($data);
        }
        
    }
		public function getgrafik()
	{
		$rec=$this->db->query('SELECT count(*) c,ket FROM `skm` group by ket')->result();
		
		 echo json_encode($rec); 
	}
	public function profil()
	{
		$r=$this->model_interf->view_profil();
		if($r){
			$data['rec']=$r->result_array();
		}else{
			$data['rec']=null;
		}
		//	var_dump($data['rec']);die;
			$data['view']='front/profil';
			$this->load->view('dash',$data);
	}
	public function modul()
	{
		$d=$this->input->get('search');
		$r=$this->model_interf->view_modul($d);
		if($r){
			$nm=$r[0]['nama_menu'];
		redirect('main/'.$nm);
			
		}else{
			  ?>
                        <script type="text/javascript">
        alert('Tidak terdapat konten yang sesuai....');
        window.history.go(-1);
      //  window.location.href="<?php echo base_url()?>main/saranaduan";
      </script>
      <?php
		}
		
	}
		public function detailinstansi()
	{
		$inis=$this->uri->segment(3);
		//var_dump($inis);die;
		$r=$this->model_interf->view_dinstansi($inis);
		if($r){
			$x=$r->result_array();
			$data['rec']=$x;
		}else{
			$data['rec']=null;
		}
      
			$data['view']='front/instansidetail';
			$this->load->view('dash',$data);
	}

			public function detaillayanan()
	{
		$inis=$this->uri->segment(3);
		$r=$this->model_instansi->view_layananinssy($inis);
	

		if($r){
			$data['rec']=$r->result_array();
		}else{
			$data['rec']=null;
		}
			//var_dump($rec[0]['logo']);die;
			$data['view']='front/detaillayanan';
			$this->load->view('dash',$data);
	}
	#berita
		public function berita()
	{
		$data['csl']= $this->model_berita->view_ber()->result_array();
		$jc= $this->model_berita->view_ber();
		$jmlb=0;
		if($jc){
			$jcc=$jc->result_array();
			$jmlb=count($jcc);
		}
		if($jmlb>0){
			$jmlp=ceil($jmlb/9);
		}else{
			$jmlp=1;
		}
		//echo $jmlp.' '.$jmlb;die;
		$data['kethal']='berita';
		$data['jmlp']=$jmlp;
		$data['jmlb']=$jmlb;
		$data['view']='front/berita';
			$this->load->view('dash',$data);
	}



public function detailberita()
	{
		
		$inis=$this->uri->segment(3);
		//var_dump($inis);die;
		$r=$this->model_berita->detailberita($inis);

		if($r){
			$rr=$r->result_array();
			$data['rec']=$rr;
		}else{
			$data['rec']=null;
		}

			$data['view']='front/detailberita';
			$this->load->view('dash',$data);
	}
public function saranaduan(){
	if(isset($_POST['submit'])){
		$n=$this->input->post('nmk');
		$e=$this->input->post('email');
		$j=$this->input->post('jnspesan');
		$l=$this->input->post('layanan');
		$p=$this->input->post('pesan');
		if($j==''||$l==''||$p==''){
			  ?>
                        <script type="text/javascript">
        alert('Pastikan inputan Anda telah terisi lengkap....');
        //window.history.go(-2);
        window.location.href="<?php echo base_url()?>main/saranaduan";
      </script>
      <?php
		}else{
			$dain = array('id_layanan' => $l, 
						'jenis'=>$j,
						'nama'=>$n,
						'email'=>$e,
						'pesan'=>$p
						);
		$rd=$this->model_interf->posall('saranadu',$dain);
		if($rd){

		 $this->session->set_flashdata('alertpostsaran','<div class="infoin animated bounceInDown" style="width:80%"><span> ID Telusur pengaduan Anda : '.$rd.' Terimakasih atas '.$j.'nya Semoga kami dapat memberikan pelayanan yang lebih baik, dan seterusnya menjadi lebih baik... ;)</span></div>');
		}else{
			 $this->session->set_flashdata('alertpostsaran','<div class="infoin animated bounceInDown" style="width:80%"><span>Input '.$j.' Anda gagal disimpan... </span></div>');
		}
	}
		
     
	}else{
		$r=$this->model_instansi->view_layananins();
		if($r){
			$re=$r->result_array();
			$data['rec']=$re;
		}else{
			$data['rec']=null;
		}
	}
	// 	var_dump($re);die;
		$data['view']='front/form_saran';
		$this->load->view('dash',$data);
	}

		function getpelayanan(){
		$p=$this->input->post("id");
		//$jp="Tulis";
		//echo '<option value="oke">oke '.$p.'</option>';die;
		$cd=$this->model_interf->getpelayanan($p)->result();
//var_dump($cd);die;

 
       
		$data=' <label for="layanan" class="col-sm-3">Layanan :</label> 
       <div class="col-md-9" ><select name="layanan" class="w-100">';   

           if($cd){
           	$data.="<option value=''>--pilih jenis pelayanan--</option>";

           } else{
           	$data.="<option value=''>--Tidak ada pelayanan sesuai Instansi yang tersedia--</option>";
           	$this->session->set_flashdata('alertpostsaran','<div class="infoin animated bounceInDown" style="width:80%"><span>Mon Maaf... </span></div>');
           }
		
		foreach ($cd as $mp){ 
			$data.="<option value='$mp->id_layanan'>$mp->info_layanan</option>";
		}
		$data.=' </select></div>';
	echo $data;
	}


	#download
		public function download(){

		$data['rec']=$this->model_interf->view_download()->result();
			$data['view']='front/view_download';
		$this->load->view('dash',$data);
	
	}
	public function donlot(){
		$filename=$this->uri->segment(3);
		if (strpos($filename, '%20') !== false) {
   
			$filename=str_replace("%20"," ",$filename);
		}
		$direktori ="./assets/files/"; 
	//	if (file_exists($direktori.$filename)) {


	 	$file_extension = strtolower(substr(strrchr($filename,"."),1));
	
		switch($file_extension){
		  case "pdf": $ctype="application/pdf"; break;
		  case "exe": $ctype="application/octet-stream"; break;
		  case "zip": $ctype="application/zip"; break;
		  case "rar": $ctype="application/rar"; break;
		  case "doc": $ctype="application/msword"; break;
		  case "docx": $ctype="application/vnd.openxmlformats-officedocument.wordprocessingml.document";break;
		  case "xls":
		  case "xlsx": $ctype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";break;
		//  case "xls": $ctype="application/vnd.ms-excel"; break;

		  case "ppt": $ctype="application/vnd.ms-powerpoint"; break;
		  case "gif": $ctype="image/gif"; break;
		  case "png": $ctype="image/png"; break;
		  case "jpeg":
		  case "jpg": $ctype="image/jpg"; break;
		  default: $ctype="application/proses";
		}

		if ($file_extension=='php'){
		  echo "<h1>Access forbidden!</h1>
		        <p>Maaf, file yang Anda download sudah tidak tersedia atau filenya (direktorinya) telah diproteksi. <br />
		        Silahkan hubungi <a href='mailto:suwanda19@gmail.com'>webmaster</a>.</p>";
		  exit;
		}
		else{
			$this->model_berita->updown($filename);
		//  mysqli_query("update download set hits=hits+1 where nama_file='$filename'");

//header('Content-Type: application/octet-stream');
header('Content-Description: File Transfer');
 header("Pragma: public"); 
		  header("Expires: 0");
		  header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		  header("Cache-Control: private",false); 
		 header("Content-Type: ".$ctype);
		  header("Content-Disposition: attachment; filename=\"".basename($filename)."\";" );
		  header("Content-Transfer-Encoding: binary");
		  header("Content-Length: ".filesize($direktori.$filename));

		  readfile("$direktori$filename");
		  exit();  
		}

//$this->load->helper('download');
//$dir=$direktori.$filename;
//var_dump($dir);die;
// force_download($dir,NULL);//bawaan ci
	}
}
