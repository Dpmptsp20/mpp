<?php defined('BASEPATH') OR
exit('No direct script access allowed');

//class Home extends MY_Controller{
	class Statistic_C extends CI_Controller{
	public function __construct(){
		parent:: __construct();
		$this->load->model('model_statistic');
	}
	public function index(){
	
		$data['jadwal']= null;
		$data['jadwaldis']= null;
		$data['foote']= null;
		$data['con']='null';
	$this->load->view('dashboard',$data);
	}

	function anti_injection($data){
		  $filter = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
		  return $filter;
	}

	public function login(){
			//$data['view']='user/login_user';
			$this->load->view('admin/login');

	}
	public function loginpoktan(){
			$data['tampil']='user/login_user';
			$this->load->view('gapoktan/home',$data);

	}
	public function loginadm(){
	//$data['view']='user/login_user';
			$this->load->view('admin/login_admin');

	}
	function log(){

		$username = $this->anti_injection($_POST['username']);
		$pass     = $this->anti_injection(md5($_POST['password']));

		// pastikan username dan password adalah berupa huruf atau angka.
		if (!ctype_alnum($username) OR !ctype_alnum($pass)){
		  echo "Sekarang loginnya tidak bisa di injeksi lho.";
		}else{
		if(isset($_POST['adm'])){$ketemu=$this->model_statistic->ceklog($username,$pass);
		}else{$ketemu=$this->model_statistic->ceklogmpp($username,$pass);}
		if ($ketemu!=false){
			$r=$ketemu->result_array();
			if(strlen($r[0]['level'])>1){
				$rex=explode('-',$r[0]['level']);
				$rexh=$rex[0];
				$this->session->set_userdata('mppanggota',$rex[1]);
			}else{
				$rexh=$r[0]['level'];
			}
		 if( $rexh<4 and $rexh>0){$status='login_admin';}//else{$status='login_user';}
			$dataar=array(
			'user'=>$r[0]['username'],
			'namalengkap'=> $r[0]['nama_lengkap'],
			'passuser'=>$r[0]['password'],
			'level'=>$rexh,
			'status'=>$status
			);

		$this->session->set_userdata($dataar);
		if(isset($_POST['adm'])){
			redirect('adminitr');
		}else{
		 redirect('main');//controller belum ada
		}
		
		}
		else{
			
		 ?>
		 	
		 	<script language="JavaScript">alert('Username atau password Anda salah'); 
		 	 window.location.href = "<?php echo site_url('main'); ?>";
			</script>
		 <?php

		}
	}




}



public function logout(){
		$this->session->sess_destroy();
		redirect('main');

}

	
}	